# OSI Prospecting System v5

Interactive LinkedIn prospecting and outreach for OSI Global, run by chatting with Claude (Cowork). Built by Andy McLean. Drops into a teammate's setup in under 30 minutes.

Start with `SETUP.md`. This README is the overview.

## What it does

1. **Discovery + qualification.** Say "find me prospects at [Company]" and Claude runs four source discovery (HubSpot, ZoomInfo, LinkedIn browse, LinkedIn keywords), reads each profile in full, verifies the person still works there, qualifies against OSI's ICP, and writes a HubSpot strategy note plus a LinkedIn connection task.
2. **Sequencing.** For every qualified Yes with an email, Claude drafts a 6 email cadence and writes all 12 values into the contact's HubSpot AI fields.
3. **You enroll, HubSpot sends.** The LinkedIn task on Day 1 is your cue. You enroll the contact in a HubSpot sequence that pulls the AI fields as tokens. HubSpot sends from the cloud. No laptop sender, no Chrome send, no scheduled tasks.

## How it flows

```
You: "find me prospects at Acme"
   |
   v
osi-prospect-qualification   verify employer, qualify, strategy note + LinkedIn task
   |
   v (Yes with email)
osi-outreach-sequence        draft 6 emails, write to contact's HubSpot AI fields
   |
   v
LinkedIn task due (Day 1)    your cue
   |
   v
You enroll in your HubSpot sequence   HubSpot sends emails 1 to 6 from the cloud
```

The run output stays tight: a discovery log, one line per candidate, and an end-of-run recap listing everyone sequenced with their sequence type, enroll date, LinkedIn URL, and a clickable HubSpot contact link. Emails are written to HubSpot, never dumped into the chat.

## The two skills (this is the whole system)

| Skill | What it does | Trigger |
|---|---|---|
| `osi-prospect-qualification` | Find and qualify. Profile / Company / Auto / Task modes. Full LinkedIn read, ZoomInfo enrichment, HubSpot strategy note + LinkedIn task, handoff to sequencing. | "find me prospects at [Company]", paste a LinkedIn URL, "run discovery", "process my enroll tasks" |
| `osi-outreach-sequence` | Draft the 6 email cadence for one Yes and write it to the HubSpot AI fields. | Called automatically by qualification on a Yes |

That pair runs the full find-to-emails loop. Optional extras exist (shorter 3 email cadence, re-engagement, weekly job-change scan) but are intentionally left out of this package to keep it simple. Ask Andy for them once you are comfortable with the core two.

## What is in this package

```
osi-prospecting-system-v5/
  README.md                 you are here
  SETUP.md                  step by step install (start here)
  FEEDBACK.md               fill in after setup and send back (SETUP Section 12)
  CLAUDE.md.template         rename to CLAUDE.md, fill in the identity placeholders
  skills/                   the two core skills + their .skill installers
  playbook/                 drafting rules, product lines, verticals, pain and objections, openers, voice, data quality
  knowledge/                email pattern resolver + the OSI master sales playbook
  scripts/                  validate_email.py (hard stop validator)
  config/                   blank queue + stagger, example block lists, holidays, blank 7 tab tracker
```

## Prerequisites

- Cowork (Claude desktop app)
- HubSpot MCP connector
- ZoomInfo MCP connector (recommended)
- Claude in Chrome extension (for reading LinkedIn during discovery, not for sending)
- Python 3 with openpyxl (`pip install openpyxl --break-system-packages`)
- A working folder at `C:\Claude-Brain\`

## Identity placeholders

Personal identity is genericized in the skills and playbook. After copying the files, replace these everywhere (one find and replace each), per SETUP Steps 3 to 4:
- `<<YOUR_NAME>>` your first name (this is your email sign-off too)
- `<<YOUR_EMAIL>>` your work email
- `<<YOUR_HUBSPOT_OWNER_ID>>` your 9 digit HubSpot owner id (critical: until you set this, prospecting would assign contacts to the wrong owner)
- `<<YOUR_HUBSPOT_PORTAL_ID>>` your HubSpot account / portal id (the number in any HubSpot record URL). Builds the clickable contact links in the output.
- `<<YOUR_GITHUB_USERNAME>>` your GitHub username

Questions: Andy McLean, OSI Global.
