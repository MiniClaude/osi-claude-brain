# Gordon's Claude Brain - Setup Guide

Welcome to your Claude Brain. This is a pre-built Second Brain for OSI Global sales, set up to work with Claude in Cowork mode.

## Quick Start

1. **Copy this entire folder** to your OneDrive (or wherever you want it synced).
2. **Open CLAUDE.md** and fill in the placeholders marked with `[GORDON - ...]`:
   - Your OSI email address
   - Your HubSpot Owner ID (ask Andy or check HubSpot settings)
3. **Open each skill file** in `skills/` and search for `[YOUR_HUBSPOT_OWNER_ID]`. Replace with your actual HubSpot Owner ID.
4. **Point Cowork to this folder** when you start a session. Claude will read CLAUDE.md first and load all the context automatically.

## What's Included

- `CLAUDE.md` - Master instructions. Claude reads this every session.
- `knowledge/` - OSI Sales Playbook, product reference guide, and qualification skill updates. Shared team knowledge.
- `skills/` - Reusable automation skills for outreach sequences, cold re-engagement, and more.
- `inbox/` - Drop raw notes here. Claude will process and file them.
- `sessions/` - Claude saves session summaries here automatically.
- `people/` - Prospect and contact profiles you build over time.
- `accounts/` - Account-level research and strategy notes.
- `outreach/` - Drafts and sent outreach, organized by prospect.

## How It Works

Start a Cowork session, point it at this folder, and tell Claude what you need. Examples:
- Paste a LinkedIn profile URL and Claude qualifies the prospect
- Say "3-email sequence for [name]" and Claude writes personalized outreach
- Say "find cold connections" and Claude searches your LinkedIn for re-engagement targets
- Drop a file in `inbox/` and say "process my notes"

## Team Context

Mark Metz and John Houston's HubSpot accounts are fair game. Claude knows this. Andy's accounts are also on the same team.

## Questions?

Ask Andy. He built the original version of this system.
