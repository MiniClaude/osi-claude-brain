---
name: osi-3email-reengagement
description: >
  Generate a hyper-personalized 3-email re-engagement sequence for OSI Global prospects
  who have already been through a previous outreach sequence. Use this skill when a LinkedIn
  profile is uploaded and indicates this is a second-touch outreach, months after
  the original sequence. Triggers on: "re-engagement," "second touch," "circle back,"
  "went through the sequence," "re-engage [name]," or any time a profile is uploaded
  and mentions it has been months since last contact. Always research recent company news
  before writing. Always run this skill before writing any re-engagement outreach.
---

> **SYNC NOTE:** This skill exists in two locations: `Claude-Brain/skills/osi-3email-reengagement/` (OneDrive — source of truth) and local Cowork `.claude/skills/`. Any edits must be applied to both. If returning after days away, check OneDrive version first and sync local if newer.

# OSI Global 3-Email Re-Engagement Sequence

## Your job

A LinkedIn profile has been provided. This person has already been through a previous outreach sequence and did not respond. They know who OSI is. Your job is to re-open the door with fresh angles, not re-introduce the company. Produce the full outreach package: strategy note, call scripts, LinkedIn message, and individual HubSpot email tasks. Each ready to press send.

Read this entire skill before producing any output.

---

## Core Rules — apply to every output

- No em-dashes (—) anywhere. Not once. Split into two sentences if needed.
- Keep prose tight and direct. No fluff.
- Emails must feel like a human wrote them to one person, not a mass blast.
- Tone: peer-to-peer. They have heard from OSI before. Acknowledge time has passed without being awkward about it.
- Emails are short. Mobile-friendly. Scannable in 10 seconds.

---

## Step 1: Research (do this before writing anything)

**HubSpot Check**
Search HubSpot for the prospect and their current company. Pull any existing notes to understand what was sent previously. Note the HubSpot owner. Only create tasks if owned by Gordon Allen ([YOUR_HUBSPOT_OWNER_ID]), Mark Metz (210187184), or John Houston (210187193).

**Company News Research**
Use ZoomInfo Scoops and News. Look for: funding rounds, acquisitions, mergers, new DC buildouts, infrastructure announcements, leadership changes, network modernization, cost-cutting or vendor consolidation, 400G/DWDM/server refresh signals.

This feeds the hook in Email 1. If no news found, fall back to a market trigger: DIMMs pricing, Park Place/Service Express merger, 400G adoption trends.

---

## Step 2: Determine contact data available

| Data available | Email tasks | Call tasks | VM + call script in notes |
|---|---|---|---|
| Email + phone | Yes | Yes | Yes |
| Email only | Yes | No | No |
| Phone only | No | Yes | Yes |
| Neither | No | No | No |

**EVERYONE regardless of data:**
- LinkedIn connection request task — always created
- Strategy and Fit note — always saved to HubSpot

---

## Step 3: Produce all outputs in this exact order

---

### 1. Strategy and Fit

**Quick Connect Keywords**
6-10 spoken trigger words to listen for on a call. Only ones relevant to this prospect and their current situation.

**Previous Employer OSI Client Check**
List previous employers. Note HubSpot matches. State clearly if none found.

**What Was Sent Before**
Summarize what OSI product lines were targeted in the original sequence based on HubSpot notes. If notes unavailable, infer from profile and title.

**New Angles for Re-Engagement**
Identify 1-2 product lines or talking points NOT covered last time. This sequence must feel different, not like a repeat.

**Target Sequences**
List OSI product lines to lead with this time. Choose from: Optics, DWDM, TPM, Compute and Components (lead DIMMs), Storage, Pre-Owned and New Networking, Professional Services (strong signal only).

**The Play**
1-2 sentences. How to re-approach with a fresh angle. Be specific about what has changed.

**The Personal Hook**
A timely trigger from research: company news, recent LinkedIn post, job change, market event. Must feel current. Do not reuse the hook from the original sequence.

---

### 2. Live Call Script

**Skip entirely if no phone number available.**

Format exactly as below — no paragraphs, no extra text:

KEYWORDS: [5-8 spoken trigger words including technical terms and any news-driven triggers]
HOOK: [Company news or personal trigger in one sentence. If nothing: none — using library opener]
OPENER: [Full opener from OPENER LIBRARY, or custom if HOOK is populated]
VM: [One line. 15 seconds max. New hook reference. Email subject line named. Ends with "I'm sending you something right now."]

#### OPENER LIBRARY

**Telco / Service Provider network engineer**
"Hey [Name], how have you been? It's Gordon with OSI Global. We supply ZR and ZR+ coherent optics to carrier teams as a secondary source when Cisco or Lumentum timelines slip. Is that something your team is running into right now?"

**Bank / Financial Institution network engineer**
"Hey [Name], how have you been? It's Gordon with OSI Global. We supply certified compatible optics to bank IT teams, mostly for the break-glass scenario where something fails and you can't wait two weeks for OEM. I was going to send a few complimentary SFPs your way. Would that be useful?"

**Enterprise IT / Consulting network engineer**
"Hey [Name], how have you been? It's Gordon with OSI Global. We work with enterprise IT teams on third party maintenance, specifically replacing OEM support on Cisco gear that is running fine but coming off warranty. Is that a conversation your team is having right now?"

**Manufacturing network engineer**
"Hey [Name], how have you been? It's Gordon with OSI Global. We supply certified compatible optics and networking spares to manufacturing IT teams for the break-glass scenario. I was going to send a few complimentary SFPs so you've got a Plan B on the shelf. Worth it?"

**Director or VP any vertical**
"Hey [Name], how have you been? It's Gordon with OSI Global. We work with infrastructure leaders on two things mostly: third party maintenance and optical hardware where OEM timelines or costs have become a problem. Is either of those a live conversation for your team?"

**Already has TPM — merger wedge**
"Hey [Name], how have you been? It's Gordon with OSI Global. With the Park Place and Service Express merger, a lot of teams have been taking a fresh look at their TPM relationships. Have you had a chance to renegotiate since the merger, or are you still on the same rates?"

**Systems / Infrastructure engineer — DIMMs**
"Hey [Name], how have you been? It's Gordon with OSI Global. We source server memory direct from Samsung and Hynix for infrastructure teams dealing with DDR4 and DDR5 cost pressure. Is that on your radar right now?"

**Storage engineer / admin**
"Hey [Name], how have you been? It's Gordon with OSI Global. We do third party maintenance on NetApp and other storage platforms for teams that have gear running fine but coming off OEM support. Is that a conversation you're having?"

**IT Director — compute and infrastructure**
"Hey [Name], how have you been? It's Gordon with OSI Global. We work with IT leaders on server memory and third party maintenance, mostly for teams carrying OEM costs on infrastructure that has been running fine for years. Is budget pressure on that something you're dealing with?"

**Procurement — TPM competitive bid**
"Hey [Name], how have you been? It's Gordon with OSI Global. We make competitive bids on multi-vendor maintenance contracts. A lot of procurement teams are using us to benchmark their current rates, especially since the Park Place and Service Express merger. Would a competitive bid be worth a look for your next cycle?"

**Transport engineer / Optical network engineer — DWDM**
"Hey [Name], how have you been? It's Gordon with OSI Global. We supply open line DWDM systems, 30 to 50% below Ciena and Nokia, with no licensing headaches. A few teams have been using us to fill capacity gaps without going back to the OEM. Is that a conversation worth having for your network?"

**Network architect — metro or long-haul WDM**
"Hey [Name], how have you been? It's Gordon with OSI Global. We do open architecture DWDM, SmartOptics platform, significantly less rack space and power than traditional Ciena or Nokia boxes, and ships faster. Is that something that fits anything on your roadmap right now?"

---

### 3. Voicemail Script

**Skip entirely if no phone number available.**

One voicemail. Never two. 15 seconds max. They know the rep already. Lead with the new hook. Name Email 1 subject line. End saying you are sending something right now.

"Hey [Name], Gordon Allen from OSI Global. [One sentence new hook]. I'm sending you something right now, subject line is [Email 1 subject]. Worth a look. [phone number at start and end]"

---

### 4. Re-Engagement Message (LinkedIn)

Under 300 characters. Short and timely. Reference the new hook. Do not mention it has been months since last contact. No mutual connections.

---

### 5. The 3-Email Re-Engagement Sequence

**Cadence:**

| # | Type | Day | Task Title |
|---|---|---|---|
| 1 | Email | 1 | 1st Touch |
| 2 | Email | 14 | Sequence Email |
| 3 | Email | 30 | Sequence Email |

**Subject line rules:**
- Email 1: You decide. Fresh and specific. References the new hook or a timely trigger. Never a repeat of the original sequence subject.
- Email 2: RE: same subject as Email 1.
- Email 3: New subject line. Clean close. Leave the door open.

**Email 1 (Day 1) — 1st Touch**
Lead with the new hook — company news, market trigger, or a product angle not covered in the original sequence. Do not re-introduce OSI. Do not acknowledge the previous sequence directly. Short — 3-4 sentences. One ask.

**Email 2 (Day 14) — Sequence Email**
Body: "Any thoughts?"

Then quoted Email 1 below in standard reply format:
> On [Day 1 due date], Gordon Allen wrote:
> [Full Email 1 text]

No greeting. No sign-off. Just "Any thoughts?" and the quote.

**Email 3 (Day 30) — Sequence Email**
New subject line. Clean close. No ask. Leave the door open with one sentence. Examples:
- "Should I close the file on this one, or is the timing just off?"
- "No worries if now isn't the right time — happy to circle back when things shift."

Quote Email 2 below in standard reply format.

**Re-engagement tone rules:**
- Do not re-introduce OSI or explain what they do.
- Do not acknowledge the previous sequence directly.
- Lead with something new — company news, market trigger, pricing window, product update.
- Make them feel like this outreach is timely, not persistent.

---

## DWDM / SmartOptics talking points

- Cost: 30-50% below Ciena and Nokia. Minimal licensing fees.
- Space and power: Significant reduction vs. traditional DWDM platforms.
- Simplicity: Easier to deploy and manage.
- Lead times: Ships faster than OEMs.
- Pedigree: Backed by original engineering core. Not grey market.

---

## OSI Product Lines

1. **Optics** — SmartOptics transceivers. Sample offer is the opening wedge.
2. **DWDM and Open Line Systems** — SmartOptics DCP, 30-50% below Ciena/Nokia.
3. **Compute and Components** — DIMMs from Samsung/Hynix/Micron. Lead with DIMMs.
4. **Storage** — NetApp TPM, pre-owned storage.
5. **TPM** — 40-60% below OEM. Multi-vendor. Gartner-recognized, privately owned, no PE.
6. **Pre-Owned and New Networking** — Pre-owned Cisco/Juniper/Arista. New Nokia authorized.
7. **Professional Services** — Strong signal only. Never lead cold.

---

## VERTICAL INTELLIGENCE

### Telco and Service Providers
Lead with optics. Do NOT open with free SFPs. TPM rarely the opener at engineer level.

### Large Banks and Financial Institutions
Lead with optics. Free SFP offer works. Do NOT lead with TPM. If known TPM, use Park Place/Service Express merger wedge.

### Professional Services and Consulting
TPM viable opener. Lead with pain not price. Free optics also works.

### Manufacturing
Free optics as break-glass insurance. TPM for aging Cisco gear.

### Healthcare
TPM with documented SLAs. DIMMs for server refresh. Gartner-recognized, privately owned, no PE matters here.

---

## COLD CALL OPENER RULES (Gong, 300M+ calls)

1. Open with "How have you been?" — 6.6x baseline meeting rate.
2. State a clear reason for calling.
3. End with a question about their world. Never "Is now a good time?"
4. Never ask "Is now a good time?"
5. Skip "Have you heard our name tossed around?"
6. Tone over words. Warm, confident, peer-to-peer.
7. Voicemails: under 20 seconds. Phone number at start AND end.

---

## TPM POSITIONING RULES

**Unknown if they have TPM:**
- Banks: optics opener, TPM is second conversation
- Consulting: TPM can open, lead with pain not savings %
- Manufacturing/enterprise: TPM strong, aging gear and OEM end-of-life is the hook

**Known TPM provider:**
Merger wedge: "With the Park Place and Service Express merger, a lot of teams have been taking a fresh look at their TPM relationships. Have you had a chance to renegotiate since the merger, or are you still on the same rates?"

---

## Step 6: Save to HubSpot automatically

### Create or update contact record

Required fields: first name, last name, job title, company, email (if found), phone (if found), city, state, timezone (hs_timezone), LinkedIn URL (hs_linkedin_url — regular linkedin.com/in/ URL).

Timezone values: america_slash_new_york / america_slash_chicago / america_slash_denver / america_slash_los_angeles / america_slash_halifax / america_slash_anchorage

### Strategy and Fit note — EVERYONE

objectType: "notes", owner [YOUR_HUBSPOT_OWNER_ID], associated to contact.

Note format (exact structure):

QUICK CONNECT KEYWORDS
[6-10 keywords, one line]

LIVE CALL SCRIPT (omit entire section if no phone number)
OPENER: [full opener from library]
VM: [one line, 15 seconds max, phone number at start and end]

THE PLAY
[One tight paragraph: new angles for re-engagement + what was sent before + the attack plan. Only include Previous Employer OSI Client Check if a HubSpot match is found. Skip it entirely if no matches.]

--- EMAIL SEQUENCE ---
Email 1 - Day 1 - [Date] - Subject: [subject]
[full email body]

Email 2 - Day 14 - [Date] - Subject: RE: [subject]
Any thoughts?
---------- On [Date], Gordon Allen wrote ----------
[Email 1 quoted]

Email 3 - Day 30 - [Date] - Subject: [new subject]
[full email body + thread]

Never use em-dashes anywhere in the note.

### LinkedIn Connection Request task — EVERYONE

Subject: "Sales Nav -- Send connection request -- [First Last] | [Company]"
Type: LINKED_IN_CONNECT, due Day 1 (same date as Email 1 / 1st Touch), owner [YOUR_HUBSPOT_OWNER_ID].
Notes: LinkedIn re-engagement message text.
Check for existing task first. If exists, skip.

### If no email AND no phone — LinkedIn tasks only

Task 1: LINKED_IN_MESSAGE, "1st LI — [First Last] | [Company]", due 7 days.
Task 2: LINKED_IN_MESSAGE, "2nd LI — [First Last] | [Company]", due 21 days.
Check for existing tasks first. If exist, skip.
