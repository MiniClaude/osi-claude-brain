# OSI Prospecting System

Plug-and-play overnight prospecting + sequencing system for OSI Global outbound. Built and tested by Andy McLean. Drops into a colleague's Cowork setup with about 30 minutes of configuration.

## What this gives you

A fully autonomous overnight pipeline:

1. **Discovery** — picks 10 cold companies (or runs your named list) and sweeps each one for IT/network/telecom prospects via LinkedIn keyword search
2. **Qualification** — for each candidate, full LinkedIn read, ZoomInfo enrichment, employer verification, HubSpot strategy note + LINKED_IN_CONNECT task
3. **Sequencing** — drafts 6-email cadence for every Yes-with-email, queues them with proper stagger (skips weekends + holidays)
4. **Sending** — every hour 11am-4pm ET weekdays, sends due emails via Outlook web (operated by Claude in Chrome)
5. **Monitoring** — daily 2:15 PM ET, scans inbox for bounces and HubSpot for replies, auto-cancels on hard bounces, auto-pauses on engagement

You give it your HubSpot owner ID, hit start, walk away. Wake up to verified prospects in HubSpot and emails in flight.

## Architecture (the 4-skill core)

```
osi-overnight-runner (orchestrator)
    ├── INVOKES osi-discovery-sweep → per company → fills queue with candidates (status: pending)
    ├── INVOKES osi-prospect-qualification → per pending candidate → produces verdict
    │       └── HANDS OFF (only on Yes-with-email) → osi-outreach-sequence → queues 6 emails
    └── (osi-outreach-sequence completes, returns to runner)
```

Each skill has ONE job. Boundaries are enforced via HARDWIRED RULES sections at the top of each SKILL.md. Future Claude sessions reading any single skill see its scope immediately.

## Why the architecture is built this way

The system was rebuilt 2026-04-26 after a "shallow qualify" optimization (added 2 days earlier) skipped LinkedIn employer verification and queued 138 emails to 23 prospects who hadn't been confirmed as still employed. Path was ripped out the same day. The current architecture splits Discovery (light, no profile reads) from Qualification (heavy, full LinkedIn read required) into separate skills so the rule-bleed problem can't repeat.

Read CLAUDE.md.template's "NO EMPLOYER VERIFICATION, NO SEQUENCE" section for the full post-mortem. If you ever see a future change that proposes "speed up by skipping LinkedIn," point at that section.

## What's in this package

```
osi-prospecting-system/
├── README.md                     ← you are here
├── SETUP.md                      ← step-by-step install (start here after reading this)
├── CLAUDE.md.template            ← rename to CLAUDE.md, edit placeholders
├── skills/
│   ├── osi-overnight-runner/     ← orchestrator
│   ├── osi-discovery-sweep/      ← per-company light sweep
│   ├── osi-prospect-qualification/ ← per-candidate heavy qualifier
│   ├── osi-outreach-sequence/    ← per-qualified-candidate email writer
│   ├── osi-email-sender/         ← Outlook web send
│   ├── osi-monitor/              ← daily bounce/reply scan
│   ├── osi-meeting-followup/     ← daily Teams meeting follow-up drafts
│   ├── osi-3email-new/           ← 3-email outreach variant
│   ├── osi-3email-reengagement/  ← 3-email re-engagement
│   ├── osi-old-customer-reengagement/ ← 5-email dormant customer reach
│   ├── osi-cold-reengagement/    ← cold 1st-degree LI reactivation
│   ├── osi-job-change-prospecting/ ← weekly job-change scanner
│   ├── osi-email-task-drafts/    ← auto-draft HubSpot email tasks
│   ├── osi-email2-rewriter/      ← daily Email 2 redrafter
│   └── *.skill                   ← packaged installers (drag into Cowork)
├── playbook/
│   ├── product-lines.md          ← OSI product lines + sequence type table
│   ├── vertical-intel.md         ← what to lead with by industry
│   ├── opener-library.md         ← 12 cold-call openers
│   ├── hubspot-data-quality.md   ← required HubSpot fields, phone format, timezone buckets
│   └── voice-rules.md            ← Andy's voice rules + banned AI vocab list
├── config/
│   ├── email-queue.json          ← empty array (your queue starts empty)
│   ├── overnight-candidates.json ← empty state (your run starts empty)
│   ├── hard-block.json           ← example structure (replace with your blocked list)
│   ├── approved-vendors.json     ← example structure (replace with your real list)
│   └── holidays.json             ← US federal holidays
└── scheduled-tasks/
    ├── 01-osi-overnight-runner-recurring.md ← prompt + cron for the orchestrator
    ├── 02-osi-email-sender.md    ← prompt + cron for the sender
    └── 03-osi-sequence-monitor.md ← prompt + cron for the monitor
```

## Prerequisites

- Cowork (Claude desktop app) installed
- HubSpot MCP connector configured with your account
- Microsoft 365 MCP connector configured with your Outlook
- ZoomInfo MCP connector (recommended; without it, Path B verification is harder)
- Claude in Chrome extension installed and signed into Outlook web
- A working folder at `C:\Claude-Brain\` (Windows) or equivalent on your platform

## How to use after install

- **"run sequences tonight"** — kicks off Auto Mode. Picks 10 cold companies you own in HubSpot (6+ months no activity), schedules Discovery Mega + Processing Recurring. Walk away.
- **"run sequences for the following companies: X, Y, Z"** — Company Mode. Same flow but with your named list.
- **Paste a LinkedIn URL** — Interactive Mode. Single prospect, qualified live, you review and click Send on Email 1 yourself.

## License / attribution

Built by Andy McLean (OSI Global). Share within OSI. Feedback welcome.
