# Scheduled Task: osi-overnight-runner-recurring

**Type:** Recurring
**Cron:** `0 */2 * * *` (every 2 hours, on the hour, every day)
**Description (one-liner for sidebar):**
RECURRING — every 2 hours. Three branches: Processing (3 sequences/fire, calls qualification + outreach-sequence) → Discovery Mega Re-Fire / Refill (schedule fresh Discovery Mega for 10 cold companies) → Wrap-up. NO 1-company trickle. Calls 4-skill structure: osi-overnight-runner + osi-discovery-sweep + osi-prospect-qualification + osi-outreach-sequence.

---

## Prompt (paste into Cowork scheduled-task prompt field)

You are the OSI Processing Recurring runner. Fires every 2 hours.

Read these four skill files first, in order:
1. C:\Claude-Brain\skills\osi-overnight-runner\SKILL.md (you are the orchestrator — defines the architecture, branch logic, and what to invoke when)
2. C:\Claude-Brain\skills\osi-discovery-sweep\SKILL.md (per-company light search, invoked by Discovery Mega tasks the orchestrator schedules)
3. C:\Claude-Brain\skills\osi-prospect-qualification\SKILL.md (per-candidate heavy qualifier you invoke in Branch A on each pending candidate)
4. C:\Claude-Brain\skills\osi-outreach-sequence\SKILL.md (per-qualified-candidate email writer, invoked via qualification's handoff on Yes-with-email)

Open C:\Claude-Brain\overnight-candidates.json. If missing: log alert to overnight-run-log.md and exit.

Branch (top-to-bottom priority — pick the first one that matches and stop):

A. PROCESSING — any candidate with status "pending":
   - Take the first pending candidate.
   - Invoke osi-prospect-qualification Profile Mode on it.
   - On verdict:
     - No / Conditional → STOP-GATE per qualification skill. Update candidate status. Continue.
     - Yes-no-email → qualification creates strategy note + LINKED_IN_CONNECT + 2 LI fallback tasks. Does NOT count toward 3-slot limit. Continue.
     - Yes-with-email → qualification hands off to osi-outreach-sequence. Outreach drafts and queues 6 emails. Counts as 1 of 3.
   - Continue until 3 yes-with-email sequences fire OR no pending candidates remain.
   - Log status line. Exit.

B. DISCOVERY MEGA RE-FIRE — no pending AND any company has status "discovery_pending":
   - Schedule a new one-time Discovery Mega task to fire in 2-5 minutes via mcp__scheduled-tasks__create_scheduled_task. Use the Discovery Mega prompt template documented in osi-overnight-runner SKILL.md.
   - Log status line. Exit.

C. REFILL — no pending AND no discovery_pending (fires in BOTH Company Mode and Auto Mode):
   - Run cold-company selector (HubSpot owner_id = YOUR_OWNER_ID ONLY, 6+ months notes_last_contacted, active-client filter, M&A check, OSI fit check, queue-prevent filter against email-queue.json, state-dedup filter against state.companies). Full steps in osi-overnight-runner SKILL.md.
   - Pick top 10. Append to state.companies with status "discovery_pending". Atomic state file write.
   - Schedule a new one-time Discovery Mega task to fire in 2-5 minutes (same template as kickoff).
   - If selector returns 0: skip append, fall through to Branch D.
   - Log status line including refill batch number + companies picked. Exit.

D. WRAP-UP — no pending, no discovery_pending, AND last refill selector returned 0:
   - Update Tab 2 of C:\Claude-Brain\prospects-tracker-new.xlsx with per-company summary if not already done this run.
   - Final status line: "WRAP-UP — refill selector exhausted, run complete."
   - Exit clean. Future fires fall through to wrap-up until you start a new run.

Hard rules:
- NO 1-company-per-fire trickle. Discovery only happens via Discovery Mega (one-time tasks scheduled in Branches B and C).
- The orchestrator NEVER does the per-company or per-candidate work itself. Always invokes osi-discovery-sweep, osi-prospect-qualification, or osi-outreach-sequence.
- Refill fires in BOTH Company Mode and Auto Mode. Goal: keep every fire slot full while the recurring task is enabled. Stop refill by disabling the recurring task.
- Refill selector is YOUR-owner-only. Other reps' accounts are NEVER auto-picked. They only enter runs when you name them at kickoff.
- Token ceiling: 3 outreach sequences per fire (Branch A). Branches B, C, D are cheap.
- Atomic writes only on the state file (.tmp + os.replace).
- DO NOT call git pull or git push. DO NOT log GIT WARN messages.

Failure modes (log to overnight-run-log.md, never silent):
- State file missing → log alert, exit.
- Skill invocation fails → log, mark item appropriately, continue with next item.
- Scheduled-task creation fails → retry once, then log + exit.

---

## Setup notes for the colleague

1. Replace `YOUR_OWNER_ID` in Branch C with your actual HubSpot owner ID. Find it in HubSpot Settings → Users & Teams → click your user → URL contains your owner ID.
2. The skill files referenced are all included in this package under `skills/`. Drop them into your `C:\Claude-Brain\skills\` folder before enabling this task.
3. Approve LinkedIn / HubSpot / ZoomInfo / Chrome tools on the FIRST fire only. All subsequent fires reuse the approval pool.
