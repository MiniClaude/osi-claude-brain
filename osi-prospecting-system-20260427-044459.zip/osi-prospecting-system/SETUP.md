# SETUP — Step-by-step install

About 30 minutes total. Do these in order.

---

## Step 1: Create the Claude-Brain folder

Make this folder on your machine. All paths in the skills assume this exact location:

**Windows:** `C:\Claude-Brain\`
**Mac/Linux:** equivalent — but you'll need to find-and-replace `C:\Claude-Brain\` with your path in every SKILL.md file. Easier on Windows.

---

## Step 2: Drop in the files

Copy the contents of this package into `C:\Claude-Brain\`:

- `skills/` → `C:\Claude-Brain\skills\` (entire folder, all 14 skills + their .skill packages)
- `playbook/` → `C:\Claude-Brain\playbook\` (entire folder, 5 markdown files)
- `config/holidays.json` → `C:\Claude-Brain\holidays.json`
- `config/email-queue.json` → `C:\Claude-Brain\email-queue.json`
- `config/overnight-candidates.json` → `C:\Claude-Brain\overnight-candidates.json`
- `config/hard-block.json` → `C:\Claude-Brain\hard-block.json`
- `config/approved-vendors.json` → `C:\Claude-Brain\approved-vendors.json`
- `CLAUDE.md.template` → `C:\Claude-Brain\CLAUDE.md` (rename it)

Final structure:
```
C:\Claude-Brain\
├── CLAUDE.md
├── skills\
│   ├── osi-overnight-runner\SKILL.md
│   ├── osi-overnight-runner.skill
│   ├── ... (13 more)
├── playbook\
│   └── ... (5 files)
├── email-queue.json (empty array)
├── overnight-candidates.json (empty)
├── hard-block.json (example)
├── approved-vendors.json (example)
└── holidays.json
```

---

## Step 3: Edit CLAUDE.md placeholders

Open `C:\Claude-Brain\CLAUDE.md`. Replace these placeholders with your info:

- `<<YOUR_NAME>>` — your first name
- `<<your_email@company.com>>` — your work email
- `<<your_role>>` — e.g. "Solutions Executive"
- `<<your_company>>` — your company name
- `<<your_company_products>>` — short description of what your company sells
- `<<YOUR_HUBSPOT_OWNER_ID>>` — find this in HubSpot Settings → Users & Teams → click your user → URL contains the owner ID number

The team / colleagues section ("JAM tree") is optional — list any teammates whose accounts you can prospect freely.

---

## Step 4: Edit your hard-block.json

Open `C:\Claude-Brain\hard-block.json`. Replace the example with real blocked addresses and domains. Keep the structure:

```json
{
  "addresses": [
    { "email": "former-prospect@example.com", "reason": "asked to be removed 2026-03-15" }
  ],
  "domains": [
    { "domain": "competitor.com", "reason": "internal — never email competitor employees" }
  ]
}
```

The osi-email-sender skill checks this list before composing every single email. Hits get auto-cancelled in the queue and surface in the daily report.

---

## Step 5: Edit your approved-vendors.json

Open `C:\Claude-Brain\approved-vendors.json`. Replace the example with the real list of companies where your firm is on the approved-vendor list:

```json
{
  "approved": [
    { "name": "Specific Company Inc", "matched_via": "MSA signed 2024" },
    { "name": "Another Company LLC", "matched_via": "in vendor portal" }
  ]
}
```

The osi-outreach-sequence skill checks this at draft time. If matched, Email 1 includes one soft acknowledgment. If not matched, never mentioned.

---

## Step 6: Install the skills in Cowork

You have 14 .skill files in `C:\Claude-Brain\skills\`. For each one, drag it into Cowork to install (Cowork's plugin/skill UI accepts drag-and-drop of .skill files).

Or, if Cowork's auto-install scheduler is on, the skill sync should detect them and prompt you to install on the next morning sync.

Verify install: open a fresh Cowork session and check that all 14 skills appear in the available skills list.

---

## Step 7: Create the 3 scheduled tasks

In Cowork's scheduled-tasks UI, create three tasks. The exact prompts and cron expressions are in the `scheduled-tasks/` folder of this package.

### Task 1: osi-overnight-runner-recurring

- Type: Recurring
- Cron: `0 */2 * * *` (every 2 hours)
- Description: paste from `scheduled-tasks/01-osi-overnight-runner-recurring.md` "Description" line
- Prompt: paste the entire prompt block from `scheduled-tasks/01-osi-overnight-runner-recurring.md`
- **IMPORTANT**: edit the prompt to replace `YOUR_OWNER_ID` with your HubSpot owner ID

### Task 2: osi-email-sender

- Type: Recurring
- Cron: `0 11,12,13,14,15,16 * * 1-5` (every hour 11am-4pm ET, Mon-Fri)
- Description: from `scheduled-tasks/02-osi-email-sender.md`
- Prompt: from `scheduled-tasks/02-osi-email-sender.md`

### Task 3: osi-sequence-monitor

- Type: Recurring
- Cron: `15 14 * * 1-5` (2:15 PM ET, Mon-Fri)
- Description: from `scheduled-tasks/03-osi-sequence-monitor.md`
- Prompt: from `scheduled-tasks/03-osi-sequence-monitor.md`

Disable all three tasks initially. Enable them one at a time after a smoke test.

---

## Step 8: Smoke test (single prospect first)

Before turning on overnight automation, test the 4-skill chain on ONE prospect interactively:

1. Open a Cowork chat session
2. Paste a LinkedIn URL of a real prospect at a known company
3. The osi-prospect-qualification skill should trigger automatically
4. Watch it run: Path A LinkedIn read → ZoomInfo enrichment → HubSpot writes → handoff to outreach-sequence
5. osi-outreach-sequence should draft 6 emails and present them for review
6. Say "ready" — Outlook should open in Chrome with Email 1 ready to send
7. Click Send. Say "sent". Emails 2-6 queue.

If anything in the chain fails, debug before enabling the recurring task.

---

## Step 9: Enable the email-sender first

Once the smoke test confirms a sequence is queued cleanly:

1. Enable `osi-email-sender` first (cron `0 11,12,13,14,15,16 * * 1-5`).
2. Wait until the next 11am-4pm ET window. Watch it fire.
3. Confirm it picks up your queued emails and sends correctly.
4. If yes, you're ready for full automation.

---

## Step 10: Enable the overnight runner

1. Enable `osi-overnight-runner-recurring` (cron `0 */2 * * *`).
2. The first fire (next even hour) detects empty state file → triggers Refill → picks 10 cold companies → schedules Discovery Mega → exits.
3. Discovery Mega fires 5 min later → sweeps the 10 companies → fills queue with candidates.
4. Subsequent runner fires (every 2 hours) work through pending candidates 3 per fire.
5. Every Yes-with-email gets the 6-email sequence queued.
6. osi-email-sender fires hourly 11am-4pm and sends due emails.
7. When the queue empties, Refill picks 10 more cold companies. Cycle continues.

To stop: disable the recurring task. State file persists; you can resume later.

---

## Step 11: Enable the monitor

1. Enable `osi-sequence-monitor` (cron `15 14 * * 1-5`).
2. Daily at 2:15 PM ET it scans your inbox for bounces and HubSpot for replies.
3. Hard bounces auto-cancel the remaining sequence. Replies auto-pause.
4. You get a clean summary in the session log.

---

## Modes you can run

- **Auto Mode:** "run sequences tonight" — Claude picks 10 cold companies you own in HubSpot. Refill keeps cycling.
- **Company Mode:** "run sequences for the following companies: Acme, Beta Inc, Gamma Corp" — Claude uses your named list. After your list drains, Refill takes over with cold Andy-owned companies (you can disable Refill by simply disabling the recurring task once your list is done).
- **Interactive Mode:** Paste a single LinkedIn URL. Claude qualifies, drafts, you review live, click Send.

---

## Troubleshooting

### "The recurring task fires but nothing happens"

Check `C:\Claude-Brain\overnight-run-log.md` — every fire logs a status line. If empty: state file may be missing or unreadable. If "WRAP-UP": runner thinks all work is done; check state file for `discovery_pending` companies and `pending` candidates.

### "Emails aren't sending"

Check Chrome is running and signed into Outlook web. The osi-email-sender skill aborts if not in the right Chrome profile. See the skill's "Setup notes" for the profile-check rule.

### "HubSpot writes are failing"

Verify your HubSpot MCP connector is configured for your account and your owner ID is correct in CLAUDE.md.

### "ZoomInfo returns no contacts"

Check ZoomInfo connector status. For large financial institutions (banks, insurance), ZoomInfo's keyword matching is unreliable — the qualification skill falls back to LinkedIn search.

### "Skill not found at runtime"

The recurring runner reads SKILL.md files via direct file paths (`C:\Claude-Brain\skills\...\SKILL.md`). If the file is at that path, it'll be found. If not, check Step 2 (folder layout).

### "How do I add a new company mid-run?"

Edit `C:\Claude-Brain\overnight-candidates.json` directly. Add a new entry to the `companies` array with `status: "discovery_pending"`. The next runner fire detects it and schedules a Discovery Mega for it.

---

## Customizing for your company

- **Product lines:** edit `playbook/product-lines.md` to reflect what your company sells.
- **Sequence templates:** edit `osi-outreach-sequence/SKILL.md` Email 1 templates (Sample-Offer Network and Sample-Offer Server) to fit your products.
- **Voice rules:** edit `playbook/voice-rules.md` to match your tone (em-dash rule is hardwired and recommended to keep).
- **Opener library:** edit `playbook/opener-library.md` with your own cold-call openers.
- **Vertical intel:** edit `playbook/vertical-intel.md` with what you've learned about your verticals.

---

## What to expect first night

If you start in Auto Mode:
- Discovery Mega fires within 5 minutes of kickoff, sweeps 10 cold companies, files candidates as pending.
- Processing fires every 2 hours, working 3 prospects per fire.
- 12 hours overnight = 6 fires = ~18 prospects qualified.
- Of those, maybe 6-10 will be Yes-with-email (depends on your ICP fit at the chosen companies).
- Each gets 6 emails queued.
- First sends start at the next 11am-4pm window the day after.

By the second night you'll have a feel for your throughput and can decide whether to bump the Refill batch size.

---

## Questions / contact

Built by Andy McLean (OSI Global). For questions: andy@osiglobal.com.
