---
name: osi-overnight-runner
description: >
  Orchestrator for OSI Global overnight prospecting and sequencing. Manages two scheduled tasks
  (Discovery Mega + Processing Recurring), the state file (overnight-candidates.json), and the
  branch logic (Processing → Discovery Mega Re-Fire → Refill → Wrap-up). Invokes osi-discovery-sweep
  per company in Discovery Mega fires, invokes osi-prospect-qualification per candidate in
  Processing fires, invokes osi-outreach-sequence on Yes-with-email handoffs. Triggers on:
  "run sequences tonight", "run a sequence", "run sequences for the following companies",
  Andy pasting a LinkedIn profile, OR scheduled-task fire (every 2 hours).
---

> Source: `C:\Claude-Brain\skills\osi-overnight-runner\` (Git, github.com/Drrewdy/Claude-Brain). Cowork `.claude/skills/` is a copy. Edit source, repackage, install.

# OSI Overnight Runner (orchestrator)

---

## 🛑 HARDWIRED RULES

This skill ONLY orchestrates. It manages scheduled tasks, the state file, and branch routing. It NEVER does the per-company or per-candidate work itself.

**This skill DOES:**
- Manage `C:\Claude-Brain\overnight-candidates.json` (the state file)
- Schedule the Discovery Mega one-time task and the Processing Recurring task at kickoff
- Read state file at every fire and route to the correct branch
- Invoke `osi-discovery-sweep` per discovery_pending company in Discovery Mega fires
- Invoke `osi-prospect-qualification` per pending candidate in Processing fires
- Forward qualification's Yes-with-email handoff to `osi-outreach-sequence`
- Run the Refill cold-company selector (HubSpot search + filters)
- Schedule fresh Discovery Mega tasks when Refill or mid-run additions add companies
- Update Excel Tab 2 (per-company summary) at run wrap-up
- Log all branch decisions and failures to `Claude-Brain/overnight-run-log.md`

**This skill DOES NOT:**
- Read individual LinkedIn profiles (delegated to `osi-prospect-qualification`).
- Run keyword search rounds at companies (delegated to `osi-discovery-sweep`).
- Draft emails (delegated to `osi-outreach-sequence`).
- Write strategy notes / LINKED_IN_CONNECT tasks (delegated to `osi-prospect-qualification`).
- Write to email-queue.json directly (delegated to `osi-outreach-sequence`).

If a Processing fire ends up doing any of the above directly instead of invoking the right skill, that is a bug. Always invoke.

---

## INPUT

- The state file `C:\Claude-Brain\overnight-candidates.json`.
- The email queue `C:\Claude-Brain\email-queue.json` (read-only at orchestration time; outreach-sequence writes to it).
- The Cowork scheduled-tasks system (Discovery Mega one-time tasks + Processing Recurring recurring task).

---

## OUTPUT

- State file updates (company status flips, candidate status flips, stagger metadata).
- Scheduled task creations (Discovery Mega for each Refill batch or mid-run addition).
- Branch decisions logged to `Claude-Brain/overnight-run-log.md`.
- Excel Tab 2 row(s) appended at wrap-up.

---

## HANDOFF (this skill is the top of the chain)

This skill INVOKES three other skills as part of orchestration. It is not handed off TO from anywhere except Andy's command at kickoff or a scheduled-task fire.

| Branch | Skill invoked | Per |
|---|---|---|
| Discovery Mega fire | `osi-discovery-sweep` | each `discovery_pending` company in state.companies |
| Processing fire (Branch A — PROCESSING) | `osi-prospect-qualification` | each `pending` candidate in state.candidates, up to 3 yes-with-email per fire |
| Processing fire (Branch A, after qualification handoff) | `osi-outreach-sequence` | each Yes-with-email handoff from qualification |

---

## RELATED SKILLS

- **`osi-discovery-sweep`** — per-company light search. Invoked by Discovery Mega.
- **`osi-prospect-qualification`** — per-candidate heavy qualifier. Invoked by Processing Branch A.
- **`osi-outreach-sequence`** — per-qualified-candidate email writer. Invoked via qualification's handoff inside Processing Branch A.

---

## ARCHITECTURE — two scheduled tasks

Overnight = exactly two tasks in Cowork's scheduled-tasks system.

### 1. Discovery Mega — one-time task

Fires once at kickoff (or at Refill, or at mid-run addition). Hits ALL companies marked `discovery_pending` in the state file in a SINGLE fire. Invokes `osi-discovery-sweep` per company. All candidates land in `state.candidates` with status `pending`. Then disables itself.

Each Refill cycle schedules a NEW Discovery Mega one-time task. Discovery Mega is the ONLY mechanism that runs Discovery Sweep on companies. There is no per-company drip.

Token budget per Discovery Mega fire: ~200-300K for 10 companies (light per-company sweep, ~20-30K each). Comfortable.

### 2. Processing Recurring — recurring task

Cron `0 */2 * * *` (every 2 hours, fires :00 of every other hour, Cowork adds ~9 min jitter).

Three branches, top-to-bottom priority:

**Branch A — PROCESSING** (any pending candidates):
- Take the first pending candidate.
- Invoke `osi-prospect-qualification` Profile Mode.
- Handle the verdict:
  - ❌ No or ⚠️ Conditional → STOP-GATE. Log. Continue to next pending.
  - ✅ Yes-no-email → qualification created strategy note + LINKED_IN_CONNECT + 2 LI fallback tasks. Does NOT count toward 3-slot limit. Continue to next pending.
  - ✅ Yes-with-email → forward qualification's handoff to `osi-outreach-sequence`. Counts as 1 of 3.
- Continue until 3 yes-with-email sequences fire OR no pending candidates remain.
- Log status line. Exit.

**Branch B — DISCOVERY MEGA RE-FIRE** (no pending candidates AND any company status `discovery_pending`):
- This branch handles the case where Andy added companies mid-run, OR Branch C (Refill) just appended companies but Discovery Mega hasn't fired on them yet.
- Schedule a new Discovery Mega one-time task to fire in 2-5 minutes. Use the Discovery Mega prompt template below.
- Log status line. Exit.

**Branch C — REFILL** (no pending candidates AND no discovery_pending companies). Fires in BOTH Company Mode and Auto Mode runs:
- Run the cold-company selector (steps below).
- Pick top 10 cold companies. Append to `state.companies` with status `discovery_pending`. Atomic write.
- Schedule a new Discovery Mega one-time task to fire in 2-5 minutes.
- If the selector returns 0 eligible companies, skip the append, fall through to Branch D.
- Log status line including refill batch number + companies picked. Exit.

**Branch D — WRAP-UP** (no pending, no discovery_pending, AND last Refill selector returned 0):
- Update Tab 2 of `prospects-tracker-new.xlsx` with per-company summary if not already done this run.
- Final status line to `overnight-run-log.md`: `WRAP-UP — refill selector exhausted, run complete.`
- Exit clean. Future fires also fall through to wrap-up until Andy starts a new run.

Token budget per Processing fire: ~150-240K (3 sequences × 50-80K each for full LinkedIn read + ZoomInfo + HubSpot writes + email drafts). Branches B and C are cheap (state-file write + one-time-task schedule). Branch D is cheap (Excel write + log).

### Why split into two tasks

Discovery is bursty (one fire = many candidates). Processing is steady (3 sequences/fire). Mixing them means Processing competes with Discovery for token budget and the backlog grows faster than it drains. Splitting keeps each task's load predictable. Two scheduled tasks = two approval pools (Andy approves LinkedIn / HubSpot / ZoomInfo / Chrome ONCE per task on first fire, all subsequent fires reuse).

### NO Discovery Fallback. NO 1-company-per-fire trickle.

The old "Discovery Fallback — pick the FIRST discovery_pending company per fire" branch was removed 2026-04-26. It dragged Discovery out across many fires and left companies sitting unprocessed. Discovery only happens via Discovery Mega (always all-companies-upfront).

### NO Auto-Mode-only Refill.

Refill fires in BOTH Company Mode and Auto Mode runs. If Andy started the run with a named list, the runner finishes that list AND THEN refills with cold Andy-owned companies, because the goal is to keep every fire slot full while the recurring task is enabled. Andy stops refill by disabling the recurring task.

The earlier "Auto-Mode Pivot" was removed because it (a) used a broken shallow-qualify shortcut, (b) drip-fed companies one-per-fire, and (c) was gated on `mode == "auto"` which surprised Andy when his Company Mode runs ended early. The current Refill is the fixed version: full upfront Discovery Mega per refill, fires in any mode.

---

## RUN MODES

### Interactive Mode (in-session, Andy at keyboard)

Andy pastes one LinkedIn profile, OR says "build a sequence for [Name]".
1. Invoke `osi-prospect-qualification` Profile Mode on the candidate.
2. If verdict is ✅ Yes-with-email, qualification hands off to `osi-outreach-sequence`.
3. `osi-outreach-sequence` drafts all 6 emails in interactive form.
4. Show review to Andy → wait for `ready` → open Outlook with Email 1 → Andy clicks Send → say `sent` → queue Emails 2-6.

Interactive Mode does NOT touch the state file or the scheduled tasks. It is a one-off.

### Company Mode (in-session kickoff, then overnight)

Andy says "run sequences for the following companies: X, Y, Z".
1. Kickoff (in-session, ~2 minutes):
   - Read existing `overnight-candidates.json`. Preserve pending entries.
   - Append Andy's named companies to `state.companies` with status `discovery_pending`. JAM-tree (Andy / Mark / John) ownership is fine in Company Mode — Mark- and John-owned companies are allowed when Andy names them explicitly.
   - Schedule **Discovery Mega** one-time task to fire in 2-5 minutes.
   - Schedule **Processing Recurring** with cron `0 */2 * * *` if not already scheduled.
   - Andy approves both schedule calls.
2. Overnight (scheduled tasks):
   - Discovery Mega fire processes all named companies in one upfront sweep, files candidates as `pending`.
   - Processing Recurring works through pending candidates 3/fire.
   - When Andy's named list is fully processed, Refill fires (yes, even in Company Mode) and picks 10 cold Andy-owned companies, schedules new Discovery Mega. Cycle continues until selector returns 0 OR Andy disables the task.

Kickoff does NOT do LinkedIn search, qualification, or outreach itself.

### Auto Mode (in-session kickoff, then overnight, no named companies)

Andy says "run sequences tonight" with no companies.
1. Kickoff:
   - Read existing `overnight-candidates.json`. Preserve pending entries.
   - Run cold-company selector (steps below). Pick top 10. Append to `state.companies` with status `discovery_pending`.
   - Schedule Discovery Mega + Processing Recurring (same as Company Mode).
2. Overnight: same as Company Mode. Refill cycles continue until cold pool exhausted.

Auto Mode is overnight-only. The selector is Andy-owned ONLY (owner ID 196669355, NOT Mark or John).

---

## COLD-COMPANY SELECTOR (Refill + Auto Mode kickoff)

Same logic in both places. Used by Refill (Branch C) and by Auto Mode kickoff.

### Selector steps (in order)

1. **HubSpot search** — `objectType: companies`, filters: `hubspot_owner_id = 196669355` (Andy ONLY — Mark 210187184 and John 210187193 are NOT eligible. Auto-picked Mark/John accounts are off-limits. They can be processed only when Andy names them explicitly in Company Mode.) AND (`notes_last_contacted` 6+ months ago OR null). Sort by `notes_last_contacted` ASC. Pull a generous candidate pool (~50).
2. **Active client filter** — for each candidate, check associated deals. Skip any with closed-won deal in last 12 months OR open deal in active pipeline stage. Do NOT use Lifecycle Stage. Log each skip: `SKIPPED: [Company] — active client (deal: [name])`.
3. **M&A check** — quick web search per candidate for recent acquisitions / mergers / rebrands. If the company is a subsidiary of an active OSI customer (e.g. Cable One brands), skip — that customer relationship is owned by another rep. Log skip: `SKIPPED: [Company] — M&A subsidiary of [parent], [parent] is OSI customer of [rep]`.
4. **OSI fit check** — keep telecom, ISPs, cable MSOs, fiber, carriers, regional MSOs, data centers, IT infrastructure plays, banks/credit unions with internal IT, hospitals/health systems with IT infra, manufacturers with real IT footprint. Skip retail, food service, pure software/SaaS, hyperscalers, professional services without IT infra ownership.
5. **Queue-prevent filter** — open `C:\Claude-Brain\email-queue.json`. Skip any company where ANY entry has `status: "pending"` OR (`status: "sent"` with `sendDate` within last 30 days).
6. **State-dedup filter** — skip any company already present in `state.companies` (any status). Prevents the same coldest companies being re-picked every refill.
7. **Rank** — by OSI fit signal first (telecom + ISPs + DCs first, then enterprise IT, then everything else), then by `notes_last_contacted` ASC. Pick the top **10**.
8. **Write** — append the 10 picks to `state.companies` with `status: "discovery_pending"`. Atomic state file write.
9. **Schedule** — schedule a new one-time Discovery Mega task to fire in 2-5 minutes.

### If selector returns 0

The cold pool is exhausted. Fall through to WRAP-UP. Log: `REFILL EXHAUSTED — selector returned 0 after filters. Wrap-up.`

### Why state-dedup is critical

Without filter 6, the selector would re-pick the same coldest companies every refill and the pool would never advance. `state.companies` is the authoritative list of "already touched this run."

### Why owner-ID filter is critical

Auto-picked Mark/John accounts are off-limits because that's the boundary between "Andy named this, JAM-tree fine" and "the runner picked this on its own, Andy-only." Mark/John accounts can still be processed in Company Mode when Andy names them explicitly.

---

## DISCOVERY MEGA prompt template

When the orchestrator schedules a new Discovery Mega one-time task, use this prompt:

```
You are running OSI Discovery Mega. Process ALL companies marked status discovery_pending in C:\Claude-Brain\overnight-candidates.json.

Read these skills first:
- C:\Claude-Brain\skills\osi-overnight-runner\SKILL.md (you are the orchestrator)
- C:\Claude-Brain\skills\osi-discovery-sweep\SKILL.md (the per-company skill you invoke)

For EACH discovery_pending company in sequence, invoke osi-discovery-sweep with the company's name, hubspot_company_id (if any), and tier. Discovery Sweep does the M&A check, HubSpot ownership check, LinkedIn keyword search rounds, captures cards into state.candidates with status pending, marks the company discovery_complete, and logs.

Discovery Sweep is LIGHT. It does NOT click into individual LinkedIn profiles. Profile reads are Processing's job (osi-prospect-qualification).

When ALL companies marked discovery_complete, exit. Do NOT do Processing — that's the recurring task's job.

Failure modes per skill: log to overnight-run-log.md, never silent. If a single company errors, log + skip + move on. Other companies still get done.
```

Token budget: ~200-300K for 10 companies. Generous ceiling — Discovery Mega's whole job is one concentrated burst.

---

## PROCESSING RECURRING prompt template

The Processing Recurring scheduled task uses this prompt:

```
You are the OSI Processing Recurring runner. Fires every 2 hours.

Read these skills first:
- C:\Claude-Brain\skills\osi-overnight-runner\SKILL.md (you are the orchestrator)
- C:\Claude-Brain\skills\osi-prospect-qualification\SKILL.md (per-candidate heavy qualifier)
- C:\Claude-Brain\skills\osi-outreach-sequence\SKILL.md (per-qualified-candidate email writer)

Open C:\Claude-Brain\overnight-candidates.json. If missing: log alert to overnight-run-log.md, exit.

Branch (top to bottom priority):

A. PROCESSING — any candidate status pending → take first, invoke osi-prospect-qualification Profile Mode. On verdict:
   - No / Conditional: STOP-GATE per qualification. Continue.
   - Yes-no-email: qualification creates strategy note + LINKED_IN_CONNECT + 2 LI fallback tasks. Does NOT count toward 3-slot limit. Continue.
   - Yes-with-email: forward qualification's handoff to osi-outreach-sequence. Counts as 1 of 3.
   Continue until 3 yes-with-email OR no pending. Log, exit.

B. DISCOVERY MEGA RE-FIRE — no pending AND any company discovery_pending → schedule a new one-time Discovery Mega task to fire in 2-5 minutes (same prompt template as kickoff). Log, exit.

C. REFILL — no pending AND no discovery_pending (fires in BOTH Company Mode and Auto Mode) → run cold-company selector (Andy-owned ONLY for the selector — Mark/John never auto-picked, 6+ months no activity, active-client filter, M&A check, OSI fit check, queue-prevent filter, state-dedup filter), pick top 10, append to state.companies as discovery_pending, schedule new Discovery Mega in 2-5 minutes. If selector returns 0, fall through to D. Log, exit.

D. WRAP-UP — no pending, no discovery_pending, AND last refill selector returned 0 → update Tab 2 of prospects-tracker-new.xlsx, write final status line "WRAP-UP — refill selector exhausted, run complete", exit clean. Future fires also fall through to wrap-up until Andy starts a new run.

NO 1-company-per-fire trickle anywhere. Discovery only happens via Discovery Mega (always all-companies-upfront).

Token ceiling: 3 outreach sequences per fire (Branch A). Branches B, C, D are cheap.

Failure modes per skill: log to overnight-run-log.md, never silent.
```

---

## STATE FILE — `overnight-candidates.json`

Path: `C:\Claude-Brain\overnight-candidates.json`. Sticky across runs. Atomic writes only (`.tmp` + `os.replace`).

### Schema

```json
{
  "run_id": "YYYY-MM-DD-name",
  "created": "ISO8601",
  "mode": "company | auto",
  "companies": [
    {
      "name": "Company Name",
      "status": "discovery_pending | discovery_complete",
      "hubspot_company_id": 12345,
      "domain": "example.com",
      "tier": "telecom | enterprise_it | manufacturing | ...",
      "added_via": "andy_named_YYYY-MM-DD | refill_YYYY-MM-DD | manual_add",
      "selection_notes": "...",
      "discovery_completed_at": "ISO8601",
      "discovery_notes": "..."
    }
  ],
  "candidates": [
    {
      "id": "firstname-lastname-company-slug",
      "firstName": "First",
      "lastName": "Last",
      "company": "Company Name",
      "linkedinUrl": "https://www.linkedin.com/in/handle",
      "title": "Director, Network Engineering",
      "source": "linkedin_search | hubspot_contact",
      "hubspotContactId": 12345,
      "status": "pending | no | conditional | yes-no-email | yes-with-email | skipped-active-sequence | pending-relookup",
      "addedDate": "YYYY-MM-DD",
      "processedDate": "ISO8601",
      "verdict_reason": "..."
    }
  ],
  "stagger": {
    "Company Name": {
      "last_day1": "YYYY-MM-DD",
      "person_count": 0
    }
  }
}
```

### Status state machines

**Companies:** `discovery_pending` → `discovery_complete`. Once complete, only flipped back to `discovery_pending` if the original Discovery used the now-removed shallow shortcut (rare) and a fresh sweep is needed.

**Candidates:**
- `pending` → after qualification → `no` / `conditional` / `yes-no-email` / `yes-with-email` / `skipped-active-sequence`
- `pending-relookup` is reserved for emergency pause (something got mis-queued and needs human review before re-qualification). The runner does NOT process `pending-relookup` candidates automatically; they must be manually flipped back to `pending`.

### Atomic writes

Always write to `state.tmp` then `os.replace(state.tmp, state)`. Never delete-then-write.

---

## KICKOFF (in-session, ~2 minutes)

Triggered by Andy's command: "run sequences for the following companies: X, Y, Z" (Company Mode), "run sequences tonight" (Auto Mode), or paste a single profile (Interactive Mode, no kickoff).

For Company Mode and Auto Mode:

1. Read existing `C:\Claude-Brain\overnight-candidates.json`. Preserve pending entries.
2. Populate company list:
   - **Company Mode:** Andy's named list, all marked `discovery_pending`. JAM-tree owners (Mark, John) are fine in Company Mode.
   - **Auto Mode:** run cold-company selector (Andy-owned ONLY), pick top 10, mark `discovery_pending`.
3. Schedule **Discovery Mega** as a one-time task firing in 2-5 minutes (or immediately via Run now). Use the Discovery Mega prompt template above.
4. Schedule **Processing Recurring** as a recurring task, cron `0 */2 * * *` if not already scheduled. Use the Processing Recurring prompt template above.
5. Done. Andy approves both schedule calls.

Kickoff does NOT invoke discovery-sweep, qualification, or outreach-sequence directly. Those run only in scheduled-task fires.

---

## MID-RUN ADDITIONS

If Andy adds a company manually to `state.companies` with `status: "discovery_pending"` while a run is in progress, the next Processing Recurring fire detects it via Branch B (Discovery Mega Re-Fire) and schedules a fresh Discovery Mega task. The new Discovery Mega processes the added company in its next fire.

If Andy adds a candidate manually to `state.candidates` with `status: "pending"`, the next Processing Recurring fire picks it up via Branch A (Processing) and runs qualification on it.

State file is the source of truth. Edits to it propagate naturally through the next fire.

---

## JAM OWNERSHIP DECISION TREE

Used by `osi-discovery-sweep` (Step 2 HubSpot ownership check) and by Refill selector (filter 1 + filter 3).

| Situation | Action |
|---|---|
| Not in HubSpot | Proceed |
| Owned by Andy (196669355) | Proceed |
| Owned by Mark (210187184) | Proceed in Company Mode (Andy named); SKIP in Refill / Auto Mode |
| Owned by John (210187193) | Proceed in Company Mode (Andy named); SKIP in Refill / Auto Mode |
| Other rep, recent activity (within 3 months) | Skip silent. Log to overnight-run-log.md |
| Other rep, no activity 3+ months, not a client | Log for account-request. Do NOT prospect |

Refill / Auto-Mode boundary is hardwired: only Andy's owner ID is auto-picked by the selector. Mark and John accounts only enter the run when Andy names them explicitly in Company Mode at kickoff.

---

## FAILURE MODES — never silent

Every failure logs to `Claude-Brain/overnight-run-log.md` with timestamp + reason:
- State file missing → log alert, exit. Don't try to recreate.
- Discovery Mega scheduling fails → retry once, then log + exit. Andy may need to manually reschedule.
- Processing Recurring scheduled task disabled → next fire never happens, but the state file is preserved. Andy can re-enable.
- Branch routing logic crashes mid-fire → log the partial state (which candidate / company was being processed), exit. Next fire picks up.
- A skill invocation fails (discovery-sweep / qualification / outreach-sequence) → log the failure, mark the company or candidate appropriately, continue with the next item. Don't abort the entire fire on one bad item.

---

## RULES

- Orchestrator never does the work itself — always invokes the right skill.
- Refill fires in BOTH Company Mode and Auto Mode. Never gate on mode for Refill.
- Refill selector is Andy-owned ONLY (Mark/John never auto-picked).
- Discovery only happens via Discovery Mega (one-time task). Never per-fire trickle.
- Every Refill cycle and every mid-run addition schedules a fresh Discovery Mega.
- State file is the source of truth. Atomic writes only.
- Branch A (Processing) is top priority every fire — leftover pending candidates from previous runs get worked first.
- 3 yes-with-email per fire is the hard ceiling for Branch A. Yes-no-email and No / Conditional do NOT count toward this ceiling.
- Wrap-up only triggers when refill selector returns 0 (true exhaustion). Future fires fall through to wrap-up cleanly until Andy starts a new run.
- Never auto-pivot to Mark/John accounts. Andy approves those explicitly via Company Mode at kickoff.
- Always log every branch decision and every failure.
