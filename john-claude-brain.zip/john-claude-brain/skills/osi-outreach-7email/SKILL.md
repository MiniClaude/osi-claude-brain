---
name: osi-outreach-7email
description: >
  Generate a full hyper-personalized 7-email outreach sequence for OSI Global sales prospecting.
  Use this skill whenever Andy uploads or pastes a LinkedIn profile and wants outreach drafted —
  whether he says "write a sequence," "do the full outreach," "run the sequence prompt," or just
  drops a profile screenshot or text. Also triggers for phrases like "build me the emails," "full
  sequence," "7-email," or "outreach for [name]." Always run this skill before writing any cold
  outreach email sequence.
---

# OSI Global Hyper-Personalized 7-Email Sequence

## Your job

Andy has given you a LinkedIn profile. Your job is to produce every piece of outreach he needs to approach this person: the strategy, the call scripts, a LinkedIn invite, and a full 7-email sequence. Everything must be specific to this person — not generic.

Read this entire skill before producing any output.

---

## Andy Rules — apply to every output

- No em-dashes (—) anywhere. Not once. Split into two sentences if needed.
- Keep prose tight and direct. No fluff.
- Emails must feel like a human wrote them to one person, not a mass blast.
- Tone: peer-to-peer, not vendor-to-buyer.

---

## Step 1: HubSpot Check (do this first, silently)

Before writing anything, search HubSpot for:
1. The prospect's name and current company
2. Each previous employer listed on their profile

Flag any that are existing OSI contacts or companies. If a match exists, note it in the Strategy section as a warm reference point.

---

## Step 2: Produce all outputs in this exact order

---

### 1. Strategy and Fit

**Quick Connect Keywords**
List 6-10 words or phrases to listen for if the cold call gets answered. These are spoken signals that confirm fit. Examples: "Cisco optics," "Smartnet," "network refresh," "400G," "server refresh," "DIMMs," "DWDM," "dark fiber," "lead times." Only list ones relevant to this prospect's profile and likely environment.

**Previous Employer OSI Client Check**
List each previous employer. Note any that appear in HubSpot as existing OSI contacts or accounts. If none found, state that clearly.

**Target Sequences**
List every OSI product line that applies to this prospect. Do not limit to one. Choose from:
- Optics
- DWDM (Open Line Systems)
- TPM
- Compute and Components (lead with DIMMs)
- Storage
- Pre-Owned and New Networking
- Professional Services (only if there is a strong signal — never lead cold with this)

**The Play**
1-2 sentences. How to attack this prospect based on their specific title, company, and background. Be concrete about what to lead with and why.

**The Personal Hook**
1-2 specific details from their LinkedIn profile that will anchor the outreach. This could be a recent job change, a certification, a past company, a specific project they mentioned, or an unusual skill. This hook must appear in Email 1 and the LinkedIn invite.

---

### 2. Live Call Script

Andy calls through Orum and has 2 seconds to scan this note. Format the output exactly like this — no paragraphs, no extra text:

KEYWORDS: [5-8 spoken trigger words that confirm fit. Include both OSI-relevant technical terms AND any news-driven triggers (e.g. if the company just announced a DC buildout, add "new DC" or "expansion"). These go first so Andy can scan them while Orum connects.]
HOOK: [If company news or a specific personal trigger was found, write it in one sentence. If nothing found, write: none — using library opener]
OPENER: [Choose one from the OPENER LIBRARY below based on vertical and role. Write it out in full. If HOOK is populated, write a custom opener using that hook instead of the library.]
VM: [One line. 15 seconds max. Reference the hook or personal detail. Name the email subject line so they know what to look for. End with "I'm sending you something right now." Never leave more than one voicemail per sequence.]

---

#### OPENER LIBRARY — pick the one that fits this prospect's vertical and role

**Telco / Service Provider network engineer (T-Mobile, AT&T, Verizon, Lumen, Zayo, Cox, etc.)**
"Hey [Name], how have you been? It's Andy with OSI Global. We supply ZR and ZR+ coherent optics to carrier teams as a secondary source when Cisco or Lumentum timelines slip. Is that something your team is running into right now?"

**Bank / Financial Institution network engineer (BofA, Citi, JPMorgan, Goldman Sachs, Wells Fargo, BNY, etc.)**
"Hey [Name], how have you been? It's Andy with OSI Global. We supply certified compatible optics to bank IT teams, mostly for the break-glass scenario where something fails and you can't wait two weeks for OEM. I was going to send a few complimentary SFPs your way. Would that be useful?"

**Enterprise IT / Consulting network engineer (KPMG, Deloitte, EY, PwC, Accenture, etc.)**
"Hey [Name], how have you been? It's Andy with OSI Global. We work with enterprise IT teams on third party maintenance, specifically replacing OEM support on Cisco gear that is running fine but coming off warranty. Is that a conversation your team is having right now?"

**Manufacturing network engineer (Forest River, Precision Castparts, PACCAR, Koch, etc.)**
"Hey [Name], how have you been? It's Andy with OSI Global. We supply certified compatible optics and networking spares to manufacturing IT teams for the break-glass scenario. I was going to send a few complimentary SFPs so you've got a Plan B on the shelf. Worth it?"

**Director or VP any vertical**
"Hey [Name], how have you been? It's Andy with OSI Global. We work with infrastructure leaders on two things mostly: third party maintenance and optical hardware where OEM timelines or costs have become a problem. Is either of those a live conversation for your team?"

**Already has TPM — merger wedge (Park Place or Service Express known customer)**
"Hey [Name], how have you been? It's Andy with OSI Global. With the Park Place and Service Express merger, a lot of teams have been taking a fresh look at their TPM relationships. Have you had a chance to renegotiate since the merger, or are you still on the same rates?"

**System engineer / Infrastructure engineer — DIMMs and server memory**
"Hey [Name], how have you been? It's Andy with OSI Global. We source server memory direct from Samsung and Hynix for infrastructure teams dealing with DDR4 and DDR5 cost pressure on their refresh cycles. Is that on your radar right now?"

**Storage engineer / Storage admin — NetApp TPM**
"Hey [Name], how have you been? It's Andy with OSI Global. We do third party maintenance on NetApp and other storage platforms for teams that have gear running fine but coming off OEM support and don't want to pay extension rates. Is that a conversation you're having?"

**IT Director — compute and infrastructure**
"Hey [Name], how have you been? It's Andy with OSI Global. We work with IT leaders on server memory and third party maintenance, mostly for teams carrying OEM costs on infrastructure that has been running fine for years. Is budget pressure on that something you're dealing with?"

**Procurement — TPM competitive bid**
"Hey [Name], how have you been? It's Andy with OSI Global. We make competitive bids on multi-vendor maintenance contracts. A lot of procurement teams are using us to benchmark their current rates, especially since the Park Place and Service Express merger. Would a competitive bid be worth a look for your next cycle?"

**Transport engineer / Optical network engineer — DWDM and Open Line Systems**
"Hey [Name], how have you been? It's Andy with OSI Global. We supply open line DWDM systems, 30 to 50% below Ciena and Nokia, with no licensing headaches. A few teams have been using us to fill capacity gaps without going back to the OEM. Is that a conversation worth having for your network?"

**Network architect — metro or long-haul WDM**
"Hey [Name], how have you been? It's Andy with OSI Global. We do open architecture DWDM, SmartOptics platform, significantly less rack space and power than traditional Ciena or Nokia boxes, and ships faster. Is that something that fits anything on your roadmap right now?"

---

### 3. Voicemail Script

One voicemail per sequence. Never two. 15 seconds max. Reference the hook or a specific detail about their world. Name the email subject line so they know what to look for. End by saying you are sending something right now.

Structure: "Hey [Name], Andy McLean from OSI Global. [One sentence referencing their specific situation or pain]. I'm sending you something right now, subject line is [subject line from Email 1]. Worth a look. [phone number twice — once at start, once at end.]"

---

### 4. LinkedIn Invite

Under 300 characters. Low friction. Focused on networking or benchmarking, not pitching. Must include the Personal Hook. Do not mention mutual connections.

---

### 5. The 7-Email Sequence

Follow all rules below before writing a single email.

**Cadence**
- Email 1: Day 1
- Email 2: Day 4
- Email 3: Day 9
- Email 4: Day 14
- Email 5: Day 21
- Email 6: Day 30
- Email 7: Day 45

**Subject line rules**
- Emails 1, 2, 3 share the same subject line. Emails 2 and 3 use "RE:" prefix.
- Emails 4 and 5 share a second subject line.
- Emails 6 and 7 share a third subject line.
- Three total subject lines across the sequence.

**Personalization rules**
- Email 1 must open with or directly reference the Personal Hook.
- Later emails should weave in references to their likely tech stack, career history, or company context where it fits naturally.
- Every email must read like it was written specifically for this one person.

**Format rules**
- Keep every email short and mobile-friendly. An IT executive reading on their phone should be able to scan it in 10 seconds.
- No bullet-point overload. Prose preferred.
- One clear ask per email. Never two.
- Do not mention mutual LinkedIn connections anywhere in the sequence.

**Tone**
Direct, human, peer-to-peer. Andy is reaching out as Andy, not as a company. No corporate speak, no "I hope this email finds you well."

---

## DWDM and Smartoptics — use these talking points when DWDM is a target sequence

Lead with:
- **Cost**: 30-50% below Ciena and Nokia. Minimal licensing fees.
- **Space and power**: Significant reduction vs. traditional DWDM platforms.
- **Simplicity**: Easier to deploy and manage. Simplified sparing vs. traditional pluggables.
- **Lead times**: Ships faster than OEMs and commodity vendors.
- **Pedigree**: Backed by original engineering core. Not a grey market product.

---

## OSI Product Lines — reference when building the sequence

1. **Optics** - SmartOptics-manufactured transceivers, private-labeled. Sample offer is the opening wedge.
2. **DWDM and Open Line Systems** - SmartOptics DCP platform, 30-50% below Ciena/Nokia.
3. **Compute and Components** - Dell/HP servers, DIMMs (Samsung/Hynix/Micron). Lead with DIMMs. DDR4 significantly cheaper than DDR5 for workloads that do not need it.
4. **Storage** - NetApp TPM, pre-owned storage, server components.
5. **TPM** - 40-60% below OEM. Multi-vendor (Cisco, Dell, HP, NetApp, Juniper, Arista). Mention Park Place/Service Express merger as a competitive talking point.
6. **Pre-Owned and New Networking** - Pre-owned Cisco/Juniper/Arista (tested, OSI TPM available). New Nokia (authorized partner).
7. **Professional Services** - Only raise this if there is a strong signal. Never lead cold with it.

---

## VERTICAL INTELLIGENCE AND CALL SCRIPT RULES

Read before writing any Live Call Script, Voicemail, or Email. The prospect's industry changes what to lead with, what to avoid, and how to frame every touchpoint.

### Telco and Service Providers (T-Mobile, AT&T, Verizon, Comcast, Lumen, Zayo, Cox, Charter, etc.)
**Lead with:** Optics. ZR, ZR+, coherent transceivers, DWDM open line systems.
**Their pain:** OEM lead times stalling 400G/800G core refreshes and DCI builds. Cisco and Lumentum timelines slipping on coherent links.
**Free sample rule:** Do NOT open with free SFPs for telcos. They deal in massive scale. A few free transceivers is noise. Lead with supply chain reliability and certifications first. Sample offer comes after credibility is established.
**TPM:** Rarely the opener at engineer level. Telco TPM decisions live at the director level, not the network engineer.
**Call angle:** "We supply ZR and ZR+ coherent optics to carrier teams as a secondary source when Cisco or Lumentum timelines slip. A few teams I work with in your space use us specifically for 400G links where lead times are stalling rollout schedules. Is that something your team is running into right now?"

### Large Banks and Financial Institutions (BofA, Citi, JPMorgan, Goldman Sachs, Wells Fargo, BNY, Morgan Stanley, etc.)
**Lead with:** Optics. Free SFP offer is the right foot in the door for banks.
**Do NOT lead with TPM.** Banks often already have TPM coverage (Park Place, Service Express, Curvature, Iron Bow). The network engineer rarely controls the maintenance contract. That sits with procurement or vendor management. For critical trading or core banking infrastructure, they stay OEM on support for regulatory reasons regardless of cost.
**TPM as upsell only:** Once you have a relationship, ask about non-critical gear: branch office switches, test lab equipment, dev environments, older hardware coming off SmartNet that is still running fine. That is where the engineer has more control.
**If they already have TPM:** Do not pitch savings percentages. Use the Park Place/Service Express merger as the wedge. See TPM Positioning Rules below.
**Call angle:** "Hey [Name], how have you been? It's Andy with OSI Global. We supply certified compatible optics to bank IT teams, mostly for the scenario where something fails and you can't wait two weeks for an OEM replacement. I was going to send a few complimentary SFPs your way just so you've got a Plan B on the shelf. Would that be useful?"

### Professional Services and Consulting (KPMG, Deloitte, EY, PwC, Accenture, etc.)
**Lead with:** TPM is a viable opener. These firms are cost-sensitive, less regulatory-constrained on hardware decisions, and the network engineer has more direct influence over vendor decisions than at a bank.
**Still:** Lead with pain before price. Not "we save you 40-60%." Instead: "Your Cisco SmartNet bill probably just got worse and a lot of teams are looking at what they are paying for on gear that has been running fine for years."
**Also works:** Free optics for break-glass. Consulting firms run standard Cisco-heavy infrastructure with relatively limited IT staff.
**If they already have TPM:** Use the Park Place/Service Express merger as the wedge. See TPM Positioning Rules below.
**Call angle:** "Hey [Name], how have you been? It's Andy with OSI Global. We work with enterprise IT teams on third party maintenance, specifically replacing OEM support on Cisco gear that is running fine but coming off warranty. Is that a conversation your team is having right now?"

### Manufacturing (Forest River, Precision Castparts, Koch plants, PACCAR, etc.)
**Lead with:** Free optics as break-glass insurance. Limited budgets, high uptime requirements, small IT staff. A spare on the shelf is immediately relatable.
**Also strong:** TPM for aging Cisco gear. Manufacturing companies often run infrastructure well past OEM support windows.
**Call angle:** "Hey [Name], how have you been? It's Andy with OSI Global. We supply certified compatible optics and networking spares to manufacturing IT teams, mostly for the break-glass scenario where something fails and you don't want to wait two weeks for OEM. I was going to send a few complimentary SFPs your way just so you've got something on the shelf. Would that be useful?"

### Healthcare (Hospital systems, health networks, pharma)
**Lead with:** Uptime, compliance, documented SLAs. TPM with clear multi-vendor coverage.
**Also strong:** DIMMs for server refresh.
**Key message:** OSI is Gartner-recognized and privately owned. No PE pressure. Engineering continuity. This matters to healthcare IT buyers.

---

## COLD CALL OPENER RULES (Gong Analysis, 300M+ Calls)

Apply to every Live Call Script and Voicemail Script produced.

1. **Open with "How have you been?"** This performs at 6.6x the baseline meeting booking rate. It creates a pattern interrupt that breaks auto-reject mode. Use it every time.
2. **State a clear reason for calling.** Calls with a stated reason convert 210% better. Never leave the prospect guessing why you dialed.
3. **End with a question about their world.** Ask about their pain directly: "Is that something your team is running into right now?" Never ask "Is that a conversation worth 60 seconds?" while already in the conversation. That is weak and meta.
4. **Never ask "Is now a good time?"** Reduces meeting booking by 40%. Signals low status and hands them an easy exit.
5. **Skip "Have you heard our name tossed around?"** Works for established brands. For OSI, the answer is almost always no, which creates an awkward opening. Express social proof differently: "We work with a few of the major carriers in your space" or "We are in a few of the large bank data centers in the northeast."
6. **Tone over words.** Warm, confident, peer-to-peer. Sound like a colleague calling about a real problem. If you stumble, laugh it off.
7. **Voicemails: under 20 seconds. Phone number at the start AND end. Mention that an email is on the way.**

---

## TPM POSITIONING RULES

**When you do not know if they have TPM:**
- Banks: Do not lead with TPM. Use optics to get in the door. TPM is the second conversation.
- Consulting/professional services: TPM can open. Lead with pain, not savings percentage.
- Manufacturing/general enterprise: TPM is strong. Aging gear and OEM end-of-life is the hook.

**When you know they already have TPM (Park Place, Service Express, Curvature, etc.):**
Never pitch "40-60% below OEM." They are already getting discounted TPM. Pitching savings to someone who already has a TPM deal sounds like you did not do your homework.

Use the Park Place/Service Express merger as the wedge:
"With the Park Place and Service Express merger, a lot of teams have been taking a fresh look at their TPM relationships. Have you had a chance to renegotiate since the merger, or are you still on the same rates and terms?"

If they engage, position OSI as: privately owned (no PE), no engineering disruption from mergers, Gartner-recognized, willing to make a competitive bid.

**OSI TPM vs. competitors:**
- Privately owned. No PE margin pressure on rates or staffing.
- No disruption from mergers or acquisitions (unlike Park Place/Service Express post-merger).
- Gartner-recognized.
- Multi-vendor: Cisco, Dell, HP, NetApp, Juniper, Arista.
- Will make a competitive bid against the existing provider.

---

## Output format

Present all 5 sections clearly labeled and in order. Use headers. Keep each section self-contained so Andy can copy any piece independently and send it without editing.

---

## Step 6: Save to HubSpot (do this automatically after producing the output)

After generating all sections, create a HubSpot note on the prospect's contact record containing ALL sections:
- Strategy and Fit (full section, including keywords)
- Live Call Script
- Voicemail Script
- LinkedIn Invite
- The full 7-email sequence (all 7 emails, labeled by day and subject line)

Andy manually loads emails into his sequence tool, so the note is the single source of truth for everything.

Use the manage_crm_objects tool to create a note (objectType: "notes") associated to the contact. Owner: Andy McLean (hubspot_owner_id: 210187193).

If the prospect is not yet in HubSpot, create the contact first before saving the note. When creating the contact:
- Navigate to their LinkedIn Sales Navigator profile and copy the full Sales Nav URL (format: `https://www.linkedin.com/sales/lead/[ID]/`). Use this as the `linkedin` field value — not the regular linkedin.com/in/ URL.
- To find the Sales Nav URL: search for the prospect by name within Sales Navigator, then click into their profile and copy the URL from the browser.
- If the Sales Nav URL cannot be retrieved (e.g. due to browser tool limitations), use the regular linkedin.com/in/ URL as a temporary placeholder and add a note on the contact record: "LinkedIn field contains regular URL — update to Sales Navigator URL when next viewing in Sales Nav."
- If you cannot locate them on Sales Nav directly, Google "[first name] [last name] [company name]" to confirm their current title and employer before creating the record.

Never use em-dashes in the note content. Replace any em-dash with a period or split into two sentences.

Also create a second HubSpot task:
- Subject: "Sales Nav — Send connection request — [First Last] | [Company]"
- Type: LINKED_IN_CONNECT
- Due: today
- Notes: the LinkedIn invite text (section 4)
- Owner: Andy McLean (210187193)
- Associated to the same contact record

---

## Step 7: Update the Excel Tracker

After saving to HubSpot, append every prospect from this session to `Claude-Brain/prospects-tracker-new.xlsx`.

Columns: Name | Title | Company | LinkedIn URL | OSI Angle | HubSpot Status | Action | Date Added | Notes

- **HubSpot Status:** "Andy — HubSpot ID [id]" / "Not found"
- **Action:** "Pursue — 7-email sequence + Sales Nav task created"
- **Notes:** The Personal Hook and lead angle in one or two sentences

Do this after every company, without being asked.
