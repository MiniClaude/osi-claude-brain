# SETUP -- Step-by-step install

About 20 minutes total. Do these in order.

---

## Step 1: Create the Claude-Brain folder

Make this folder on your machine. All paths in the skills assume this exact location:

**Windows:** `C:\Claude-Brain\`

---

## Step 2: Drop in the files

Copy the contents of this package into `C:\Claude-Brain\`:

- `skills/` -> `C:\Claude-Brain\skills\` (entire folder, all 5 skills + their .skill packages)
- `playbook/` -> `C:\Claude-Brain\playbook\` (entire folder, 6 markdown files)
- `config/holidays.json` -> `C:\Claude-Brain\holidays.json`
- `config/email-queue.json` -> `C:\Claude-Brain\email-queue.json`
- `config/overnight-candidates.json` -> `C:\Claude-Brain\overnight-candidates.json`
- `config/hard-block.json` -> `C:\Claude-Brain\hard-block.json`
- `config/approved-vendors.json` -> `C:\Claude-Brain\approved-vendors.json`
- `CLAUDE.md.template` -> `C:\Claude-Brain\CLAUDE.md` (rename it)

Final structure:
```
C:\Claude-Brain\
  CLAUDE.md
  skills\
    osi-prospect-qualification\SKILL.md
    osi-prospect-qualification.skill
    osi-outreach-sequence\SKILL.md
    osi-outreach-sequence.skill
    osi-email-sender\SKILL.md
    osi-email-sender.skill
    osi-monitor\SKILL.md
    osi-monitor.skill
    osi-email2-rewriter\SKILL.md
    osi-email2-rewriter.skill
  playbook\
    drafting-rules.md
    product-lines.md
    vertical-intel.md
    opener-library.md
    hubspot-data-quality.md
    voice-rules.md
  email-queue.json
  overnight-candidates.json
  hard-block.json
  approved-vendors.json
  holidays.json
```

---

## Step 3: Edit CLAUDE.md placeholders

Open `C:\Claude-Brain\CLAUDE.md`. Replace these placeholders with your info:

- `<<YOUR_NAME>>` -- your first name
- `<<your_email@company.com>>` -- your work email
- `<<your_role>>` -- e.g. "Solutions Executive"
- `<<your_company>>` -- your company name
- `<<your_company_products>>` -- short description of what your company sells
- `<<YOUR_HUBSPOT_OWNER_ID>>` -- find this in HubSpot: click your avatar top right, then Profile & Preferences. The Owner ID is a 9-digit number.
- `<<YOUR_GITHUB_USERNAME>>` -- your GitHub username (set up in Step 5)

---

## Step 4: Edit your hard-block.json

Open `C:\Claude-Brain\hard-block.json`. Add any email addresses or domains that should never receive emails:

```json
{
  "addresses": [
    { "email": "person@example.com", "reason": "asked to be removed 2026-03-15" }
  ],
  "domains": [
    { "domain": "competitor.com", "reason": "never email competitor employees" }
  ]
}
```

The osi-email-sender skill checks this list before every send.

---

## Step 5: Edit your approved-vendors.json

Open `C:\Claude-Brain\approved-vendors.json`. Add companies where your firm is on the approved-vendor list:

```json
{
  "approved": [
    { "name": "Specific Company Inc", "matched_via": "MSA signed 2024" }
  ]
}
```

The osi-outreach-sequence skill checks this at draft time and adjusts Email 1 language accordingly.

---

## Step 6: Install the skills in Cowork

You have 5 .skill files in `C:\Claude-Brain\skills\`. For each one, drag it into Cowork chat to install.

Verify install: open a fresh Cowork session and check that all 5 skills appear in the available skills list.

---

## Step 7: Create the 2 scheduled tasks

In Cowork's scheduled-tasks UI, create two tasks. The exact prompts and cron expressions are in the `scheduled-tasks/` folder.

### Task 1: osi-email-sender

- Type: Recurring
- Cron: `0 11,12,13,14,15,16 * * 1-5` (every hour 11am-4pm ET, Mon-Fri)
- Prompt: from `scheduled-tasks/02-osi-email-sender.md`

### Task 2: osi-sequence-monitor

- Type: Recurring
- Cron: `15 14 * * 1-5` (2:15 PM ET, Mon-Fri)
- Prompt: from `scheduled-tasks/03-osi-sequence-monitor.md`

Disable both tasks initially. Enable after smoke test below.

---

## Step 8: Smoke test

Before enabling automation, test on ONE prospect interactively:

1. Open a Cowork chat session
2. Say: "find me prospects at [one company you want to prospect]"
3. Watch it run: LinkedIn sweep -> qualification -> ZoomInfo -> HubSpot writes -> outreach sequence drafts
4. The skill auto-queues the emails. Review the confirmation output: Name | Sequence type | Day 1 date.
5. Confirm Email 1 sends at the next 4pm ET window (once email-sender is enabled).

If the chain runs clean, you're set.

---

## Step 9: Enable the email sender

Once a sequence is queued:

1. Enable `osi-email-sender` (cron `0 11,12,13,14,15,16 * * 1-5`).
2. Wait for the next 11am-4pm ET window. Confirm it sends correctly.

---

## Step 10: Enable the monitor

1. Enable `osi-sequence-monitor` (cron `15 14 * * 1-5`).
2. Daily at 2:15 PM ET it scans your inbox for bounces and HubSpot for replies.
3. Hard bounces auto-cancel the remaining sequence. Replies auto-pause.

---

## How to run prospecting

**Named company:** "Find me prospects at Acme Corp"
Sweeps LinkedIn at that company, qualifies every candidate, queues a 6-email sequence for every Yes.

**Auto-pull:** "Run discovery"
Pulls your coldest HubSpot accounts automatically and runs the same flow.

**Single prospect:** Paste a LinkedIn URL
Qualifies and sequences that one person immediately.

---

## Customizing for your company

- **Product lines:** edit `playbook/product-lines.md` to reflect what your company sells.
- **Email templates:** edit `skills/osi-outreach-sequence/SKILL.md` Email 1 templates to fit your products.
- **Voice rules:** edit `playbook/voice-rules.md` to match your tone.
- **Opener library:** edit `playbook/opener-library.md` with your own cold-call openers.
- **Vertical intel:** edit `playbook/vertical-intel.md` with what you've learned about your verticals.

---

## Troubleshooting

**"Emails aren't sending"**
Check Chrome is running and signed into Outlook web. The osi-email-sender skill requires the Claude in Chrome extension.

**"HubSpot writes are failing"**
Verify your HubSpot MCP connector is configured and your owner ID is correct in CLAUDE.md.

**"ZoomInfo returns no contacts"**
Check ZoomInfo connector status. For large financial institutions, the qualification skill falls back to LinkedIn search automatically.

---

## Questions / contact

Built by Andy McLean (OSI Global). For questions: andy@osiglobal.com.
