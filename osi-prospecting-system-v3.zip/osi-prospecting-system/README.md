# OSI Prospecting System

Interactive LinkedIn prospecting + outreach sequencing system. Built by Andy McLean. Drops into a colleague's Cowork setup in about 20 minutes.

## What this gives you

A complete prospecting-to-pipeline workflow you run via Cowork chat:

1. **Discovery + Qualification** -- say "find me prospects at [Company]" or "run discovery" and Claude sweeps LinkedIn, qualifies every candidate (full LinkedIn read, ZoomInfo enrichment, employer verification), writes HubSpot strategy notes + connection request tasks, and immediately hands off to sequencing.
2. **Sequencing** -- for every qualified Yes, drafts a 6-email cadence and queues it with proper stagger (skips weekends + holidays)
3. **Sending** -- scheduled task fires every hour 11am-4pm ET weekdays, sends due emails via Outlook web
4. **Monitoring** -- daily 2:15 PM ET, scans inbox for bounces and HubSpot for replies, auto-cancels on hard bounces, auto-pauses on engagement

## How prospecting works

```
You: "find me prospects at Acme" or "run discovery"
    |
    v
osi-prospect-qualification
    LinkedIn keyword search -> full profile reads -> ZoomInfo enrichment
    Verdict: Yes / No / Conditional
    HubSpot writes: contact, strategy note, LINKED_IN_CONNECT task
    |
    v (Yes-with-email only)
osi-outreach-sequence
    Drafts 6 emails -> queues to email-queue.json
    |
    v (automated)
osi-email-sender (11am-4pm ET windows)
    Sends due emails via Outlook web
```

Everything runs in the same chat session. You watch it work, get a summary when it's done.

## The 5 skills

- **`osi-prospect-qualification`** -- the core skill. Three modes: single prospect (paste a LinkedIn URL), Company Mode ("find me prospects at [Company]"), Auto Mode ("run discovery" -- pulls cold accounts from HubSpot automatically). Does the full LinkedIn read, ZoomInfo enrichment, HubSpot writes, and hands off to sequencing on every Yes.
- **`osi-outreach-sequence`** -- drafts 6-email cadence for every Yes-with-email, queues with stagger (skips weekends + holidays), updates the LINKED_IN_CONNECT task due date
- **`osi-email-sender`** -- fires 11am-4pm ET weekdays. Reads queue, sends due emails via Outlook web
- **`osi-monitor`** -- daily 2:15 PM ET. Scans inbox for bounces, cross-references HubSpot for replies, auto-cancels on hard bounces, auto-pauses on non-OOO replies
- **`osi-email2-rewriter`** -- daily 9:30 AM ET. Redrafts pain-led Email 2s before the 11am send window

## What's in this package

```
osi-prospecting-system/
  README.md                      <- you are here
  SETUP.md                       <- step-by-step install (start here)
  CLAUDE.md.template             <- rename to CLAUDE.md, fill in placeholders
  skills/
    osi-prospect-qualification/  <- core qualifier (all three modes)
    osi-outreach-sequence/       <- 6-email drafter + queue writer
    osi-email-sender/            <- Outlook web sender
    osi-monitor/                 <- daily bounce/reply scan
    osi-email2-rewriter/         <- Email 2 rewriter
    *.skill                      <- packaged installers (drag into Cowork)
  playbook/
    drafting-rules.md            <- email voice rules, templates, banned phrases (mandatory)
    product-lines.md             <- OSI product lines + sequence type table
    vertical-intel.md            <- what to lead with by industry
    opener-library.md            <- cold-call openers
    hubspot-data-quality.md      <- required HubSpot fields, phone format, timezone buckets
    voice-rules.md               <- voice rules + banned AI vocab
  config/
    email-queue.json             <- empty array (your queue starts empty)
    overnight-candidates.json    <- email stagger state (starts empty)
    hard-block.json              <- example structure (replace with your blocked list)
    approved-vendors.json        <- example structure (replace with your real list)
    holidays.json                <- US federal holidays
  scheduled-tasks/
    02-osi-email-sender.md       <- prompt + cron for the sender
    03-osi-sequence-monitor.md   <- prompt + cron for the monitor
```

## Prerequisites

- Cowork (Claude desktop app) installed
- HubSpot MCP connector configured with your account
- Microsoft 365 MCP connector configured with your Outlook
- ZoomInfo MCP connector (recommended)
- Claude in Chrome extension installed and signed into Outlook web
- Working folder at `C:\Claude-Brain\`

## Questions / contact

Built by Andy McLean (OSI Global). Questions: andy@osiglobal.com.
