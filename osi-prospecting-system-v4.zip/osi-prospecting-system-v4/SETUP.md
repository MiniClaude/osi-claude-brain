# SETUP -- Step-by-step install (v4)

About 25 minutes total. Do these in order.

---

## Step 1: Create the Claude-Brain folder

Make this folder on your machine. All paths in the skills assume this exact location:

**Windows:** `C:\Claude-Brain\`

Initialize it as a Git repo so you can sync across machines and keep a backup:

```bash
cd C:\Claude-Brain
git init
git remote add origin https://github.com/<<YOUR_GITHUB_USERNAME>>/Claude-Brain.git
```

---

## Step 2: Drop in the files

Copy the contents of this package into `C:\Claude-Brain\`:

- `skills/` -> `C:\Claude-Brain\skills\` (entire folder, all 6 skills + their .skill packages)
- `playbook/` -> `C:\Claude-Brain\playbook\` (6 markdown files)
- `knowledge/` -> `C:\Claude-Brain\knowledge\` (1 markdown file: email-pattern-resolver.md)
- `scripts/` -> `C:\Claude-Brain\scripts\` (1 Python file: validate_email.py)
- `config/holidays.json` -> `C:\Claude-Brain\holidays.json`
- `config/email-queue.json` -> `C:\Claude-Brain\email-queue.json`
- `config/overnight-candidates.json` -> `C:\Claude-Brain\overnight-candidates.json`
- `config/hard-block.json` -> `C:\Claude-Brain\hard-block.json`
- `config/approved-vendors.json` -> `C:\Claude-Brain\approved-vendors.json`
- `config/do-not-auto-prospect.json` -> `C:\Claude-Brain\do-not-auto-prospect.json`
- `config/prospects-tracker-new.xlsx` -> `C:\Claude-Brain\prospects-tracker-new.xlsx`
- `CLAUDE.md.template` -> `C:\Claude-Brain\CLAUDE.md` (rename it, then fill in placeholders)

Final structure:
```
C:\Claude-Brain\
  CLAUDE.md
  email-queue.json
  overnight-candidates.json
  hard-block.json
  approved-vendors.json
  do-not-auto-prospect.json
  holidays.json
  prospects-tracker-new.xlsx
  overnight-run-log.md          <- create this as an empty file
  skills\
    osi-prospect-qualification\SKILL.md
    osi-prospect-qualification.skill
    osi-outreach-sequence\SKILL.md
    osi-outreach-sequence.skill
    osi-3email-reengagement\SKILL.md
    osi-3email-reengagement.skill
    osi-email-sender\SKILL.md
    osi-email-sender.skill
    osi-monitor\SKILL.md
    osi-monitor.skill
    osi-email2-rewriter\SKILL.md
    osi-email2-rewriter.skill
  playbook\
    drafting-rules.md
    product-lines.md
    vertical-intel.md
    opener-library.md
    hubspot-data-quality.md
    voice-rules.md
  knowledge\
    email-pattern-resolver.md
  scripts\
    validate_email.py
```

Create the empty log file now:
```bash
echo "" > C:\Claude-Brain\overnight-run-log.md
```

---

## Step 3: Edit CLAUDE.md placeholders

Open `C:\Claude-Brain\CLAUDE.md`. Replace every placeholder marked `<<...>>`:

- `<<YOUR_NAME>>` -- your first name (e.g. "Andy")
- `<<your_email@company.com>>` -- your work email
- `<<your_role>>` -- e.g. "Solutions Executive"
- `<<your_company>>` -- your company name (e.g. "OSI Global")
- `<<your_company_products>>` -- one sentence on what your company sells
- `<<YOUR_HUBSPOT_OWNER_ID>>` -- 9-digit number. Find it in HubSpot: avatar top right > Profile & Preferences > Owner ID.
- `<<YOUR_GITHUB_USERNAME>>` -- your GitHub username

---

## Step 4: Edit hard-block.json

Open `C:\Claude-Brain\hard-block.json`. Add any addresses that should never receive emails:

```json
{
  "addresses": [
    { "email": "person@example.com", "reason": "asked to be removed 2026-03-15", "blockedAt": "2026-03-15" }
  ]
}
```

The osi-email-sender skill checks this list before every send.

---

## Step 5: Edit approved-vendors.json

Open `C:\Claude-Brain\approved-vendors.json`. Add companies where you are on the approved vendor list:

```json
{
  "approved_vendor_companies": ["Company A", "Company B"],
  "how_to_match": "Case-insensitive substring match against the prospect company name.",
  "usage_rule": "If the prospect company matches, include one soft acknowledgment in Email 1 and one reminder in Email 3 or 4."
}
```

---

## Step 6: Edit do-not-auto-prospect.json

Open `C:\Claude-Brain\do-not-auto-prospect.json`. Add companies that should never be surfaced automatically in Auto Mode (they can still be prospected manually):

```json
[
  { "company": "Example Corp", "reason": "Strategic account -- manual only", "dateAdded": "2026-01-01" }
]
```

---

## Step 7: Install the skills in Cowork

You have 6 .skill files in `C:\Claude-Brain\skills\`. Drag each one into a Cowork chat window to install.

Skills to install:
1. `osi-prospect-qualification.skill`
2. `osi-outreach-sequence.skill`
3. `osi-3email-reengagement.skill`
4. `osi-email-sender.skill`
5. `osi-monitor.skill`
6. `osi-email2-rewriter.skill`

Verify: open a fresh Cowork session and confirm all 6 appear in the available skills list.

---

## Step 8: Create the 3 scheduled tasks

In Cowork's scheduled-tasks UI, create three tasks. Prompts are in `scheduled-tasks/`.

### Task 1: osi-email2-rewriter (9:30 AM ET)

- Type: Recurring
- Cron: `30 9 * * 1-5`
- Prompt: from `scheduled-tasks/01-osi-email2-rewriter.md`
- Enable AFTER Step 10 smoke test

### Task 2: osi-email-sender (11am-4pm ET, every hour)

- Type: Recurring
- Cron: `0 11,12,13,14,15,16 * * 1-5`
- Prompt: from `scheduled-tasks/02-osi-email-sender.md`
- Enable AFTER Step 10 smoke test

### Task 3: osi-sequence-monitor (2:15 PM ET)

- Type: Recurring
- Cron: `15 14 * * 1-5`
- Prompt: from `scheduled-tasks/03-osi-sequence-monitor.md`
- Enable AFTER Step 10 smoke test

Disable all three tasks initially.

---

## Step 9: Verify Python + openpyxl

The qualification and outreach skills write to `prospects-tracker-new.xlsx` via Python/openpyxl. Confirm it is available:

```bash
python3 -c "import openpyxl; print('ok')"
```

If it fails:
```bash
pip install openpyxl --break-system-packages
```

---

## Step 10: Smoke test

Test on ONE prospect interactively before enabling any automation:

1. Open a Cowork chat session.
2. Say: "find me prospects at [one company you want to prospect]"
3. Watch it run: LinkedIn browse + keyword rounds -> qualification -> ZoomInfo enrichment -> HubSpot writes -> outreach sequence drafts -> queue write confirmation.
4. You should see: `Queued: [Name] | [Sequence type] | Day 1 YYYY-MM-DD`
5. Check `C:\Claude-Brain\email-queue.json` and confirm 6 entries exist with `status: pending`.
6. Check `C:\Claude-Brain\prospects-tracker-new.xlsx` Tab1 and confirm a row was appended.
7. Check HubSpot and confirm the contact, strategy note, and LINKED_IN_CONNECT task were created.

If the chain runs clean, proceed to Step 11.

---

## Step 11: Enable the automation

Once the smoke test passes:

1. Enable `osi-email2-rewriter` (cron `30 9 * * 1-5`).
2. Enable `osi-email-sender` (cron `0 11,12,13,14,15,16 * * 1-5`). Confirm the first send fires correctly.
3. Enable `osi-sequence-monitor` (cron `15 14 * * 1-5`).

---

## How to run prospecting

**Named company (Company Mode):**
"Find me prospects at Acme Corp"
Full 4-source discovery (HubSpot + ZoomInfo + LinkedIn browse + LinkedIn keywords). Qualifies every candidate. Queues 6-email sequences for every Yes.

**Multiple companies (batch):**
"Find me prospects at Acme, Beta Corp, and Gamma Inc"
Runs full Company Mode on each in sequence without stopping between them.

**Auto-pull (Auto Mode):**
"Run discovery" or "sweep my accounts"
Pulls your coldest HubSpot accounts from the Company Pipeline tab, pre-checks each one, presents a clean list, then runs Company Mode on each.

**Single prospect:**
Paste a LinkedIn URL.
Qualifies and sequences that one person immediately.

**Re-engagement:**
"Re-engage [name]" or paste a LinkedIn profile.
Runs `osi-3email-reengagement` -- 3-email second-touch sequence for prospects who already went through the standard sequence.

---

## The Excel tracker

`prospects-tracker-new.xlsx` has 7 tabs:

| Tab | Purpose |
|---|---|
| Tab1 | Every prospect sequenced (auto-appended by osi-outreach-sequence) |
| Prospects | Alternate prospects view (same columns as Tab1) |
| Company Status | Per-company run log (company, date, result) |
| Unenrolled | Contacts removed from sequences |
| Companies Prospected | Running log of every company ever prospected |
| Do Not Auto-Prospect | Companies excluded from Auto Mode |
| Company Pipeline | Master pipeline: all Andy-owned companies 200+ emp, ICP-scored, sorted |

The Company Pipeline tab is built by Auto Mode on first run. Rebuild it any time by saying "rebuild pipeline."

---

## Customizing for your company

- **Product lines:** edit `playbook/product-lines.md` to reflect what your company sells and the sequence-type table.
- **Email templates:** edit `skills/osi-outreach-sequence/SKILL.md` Email 1 templates to fit your products.
- **Voice rules:** edit `playbook/voice-rules.md` to match your writing tone.
- **Opener library:** edit `playbook/opener-library.md` with your own cold-call openers.
- **Vertical intel:** edit `playbook/vertical-intel.md` with what you know about your target industries.
- **ICP criteria:** edit `skills/osi-prospect-qualification/SKILL.md` THREE-POINT QUALIFICATION CHECK and DISQUALIFIERS sections.

---

## Troubleshooting

**"Emails aren't sending"**
Check Chrome is running and signed into Outlook web. The osi-email-sender skill requires the Claude in Chrome extension.

**"validate_email.py not found" or "validator raises ValueError"**
Confirm `C:\Claude-Brain\scripts\validate_email.py` exists. If the validator raises, the email body violated a hard rule (em-dash, banned vocab, etc.). Read the error and fix the draft.

**"HubSpot writes are failing"**
Verify HubSpot MCP connector is configured and your owner ID placeholder in CLAUDE.md is correct.

**"ZoomInfo returns no contacts"**
Check ZoomInfo connector status. For financial institutions and scrubbed-profile firms, the qualification skill falls back to LinkedIn browse automatically.

**"Excel update fails"**
Confirm openpyxl is installed: `python3 -c "import openpyxl; print('ok')"`. Excel failures are logged to overnight-run-log.md but do not block the email queue.

---

## Questions / contact

Built by Andy McLean (OSI Global). Questions: andy@osiglobal.com.
