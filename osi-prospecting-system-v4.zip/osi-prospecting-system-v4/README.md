# OSI Prospecting System v4

Interactive LinkedIn prospecting + outreach sequencing system. Built by Andy McLean. Drops into a colleague's Cowork setup in about 25 minutes.

## What this gives you

A complete prospecting-to-pipeline workflow you run via Cowork chat:

1. **Discovery + Qualification** -- say "find me prospects at [Company]" and Claude runs 4-source discovery (HubSpot, ZoomInfo, LinkedIn browse, LinkedIn keywords), reads every profile in full, qualifies against your ICP, writes HubSpot strategy notes + connection request tasks, and hands off to sequencing.
2. **Sequencing** -- for every qualified Yes, drafts a 6-email cadence and queues it with proper stagger (skips weekends + holidays)
3. **Re-engagement** -- for prospects who already went through a sequence, drafts a hyper-personalized 3-email second-touch
4. **Email 2 rewriting** -- daily 9:30 AM ET, redrafts generic pain-led follow-ups with fresh research before the send window
5. **Sending** -- scheduled task fires every hour 11am-4pm ET weekdays, sends due emails via Outlook web
6. **Monitoring** -- daily 2:15 PM ET, scans inbox for bounces and HubSpot for replies, auto-cancels on hard bounces, auto-pauses on engagement

## How prospecting works

```
You: "find me prospects at Acme" or "run discovery"
    |
    v
osi-prospect-qualification
    4-source discovery: HubSpot + ZoomInfo + LinkedIn browse + LinkedIn keywords
    Full profile reads. Verdict: Yes / No / Conditional
    HubSpot writes: contact, strategy note, LINKED_IN_CONNECT task
    |
    v (Yes-with-email only)
osi-outreach-sequence
    Drafts 6 emails -> queues to email-queue.json with stagger
    |
    v (automated)
osi-email2-rewriter (9:30 AM ET)
    Redrafts generic Email 2s before send window
    |
    v (automated)
osi-email-sender (11am-4pm ET)
    Sends due emails via Outlook web
    |
    v (automated)
osi-monitor (2:15 PM ET)
    Scans for bounces + replies, auto-cancels/pauses
```

For re-engagement:
```
You: "re-engage [name]" or paste LinkedIn profile + mention months since last contact
    |
    v
osi-3email-reengagement
    Researches recent company news
    Drafts 3-email second-touch sequence
    Queues to email-queue.json
```

## The 6 skills

| Skill | What it does | Trigger |
|---|---|---|
| `osi-prospect-qualification` | Core qualifier. Company Mode / Profile Mode / Auto Mode. Full LinkedIn read, ZoomInfo enrichment, HubSpot writes, handoff to sequencing. | "find me prospects at [Company]", paste LinkedIn URL, "run discovery" |
| `osi-outreach-sequence` | Drafts 6-email cadence for one Yes-with-email prospect. Queues with stagger. Updates LI connect task. | Called automatically by qualification on Yes verdict |
| `osi-3email-reengagement` | 3-email re-engagement for prospects who already received the standard sequence. | "re-engage [name]", "second touch", "circle back" |
| `osi-email2-rewriter` | Redrafts pain-led Email 2s before the 11am window. Replaces generic follow-ups with research-backed bodies. | Scheduled 9:30 AM ET, or "rewrite today's email 2s" |
| `osi-email-sender` | Reads queue, sends due emails via Outlook web (Claude in Chrome). | Scheduled every hour 11am-4pm ET |
| `osi-monitor` | Scans for bounces + replies. Auto-cancels on hard bounce. Auto-pauses on engagement. | Scheduled 2:15 PM ET |

## What's in this package

```
osi-prospecting-system-v4/
  README.md                          <- you are here
  SETUP.md                           <- step-by-step install (start here)
  CLAUDE.md.template                 <- rename to CLAUDE.md, fill in placeholders
  skills/
    osi-prospect-qualification/      <- core qualifier (all three modes)
    osi-outreach-sequence/           <- 6-email drafter + queue writer
    osi-3email-reengagement/         <- 3-email re-engagement
    osi-email-sender/                <- Outlook web sender
    osi-monitor/                     <- daily bounce/reply scan
    osi-email2-rewriter/             <- Email 2 rewriter
    *.skill                          <- packaged installers (drag into Cowork)
  playbook/
    drafting-rules.md                <- email voice rules, templates, banned phrases (mandatory)
    product-lines.md                 <- OSI product lines + sequence type table
    vertical-intel.md                <- what to lead with by industry
    opener-library.md                <- cold-call openers
    hubspot-data-quality.md          <- required HubSpot fields, phone format, timezone buckets
    voice-rules.md                   <- voice rules + banned AI vocab
  knowledge/
    email-pattern-resolver.md        <- algorithm for resolving the right email address
  scripts/
    validate_email.py                <- hard-stop validator. Called before every queue write.
  config/
    email-queue.json                 <- empty array (your queue starts empty)
    overnight-candidates.json        <- email stagger state (starts empty)
    hard-block.json                  <- example structure (replace with your blocked list)
    approved-vendors.json            <- example structure (replace with your real list)
    do-not-auto-prospect.json        <- companies excluded from Auto Mode
    holidays.json                    <- US federal holidays
    prospects-tracker-new.xlsx       <- blank Excel tracker with all 7 tabs pre-built
  scheduled-tasks/
    01-osi-email2-rewriter.md        <- prompt + cron for the Email 2 rewriter
    02-osi-email-sender.md           <- prompt + cron for the sender
    03-osi-sequence-monitor.md       <- prompt + cron for the monitor
```

## Prerequisites

- Cowork (Claude desktop app) installed
- HubSpot MCP connector configured with your account
- Microsoft 365 MCP connector configured with your Outlook
- ZoomInfo MCP connector (strongly recommended)
- Claude in Chrome extension installed and signed into Outlook web
- Python 3 with openpyxl installed (`pip install openpyxl --break-system-packages`)
- Working folder at `C:\Claude-Brain\`

## What changed in v4 (from v3)

- **Both core skills updated to current versions.** `osi-prospect-qualification` nearly doubled in size since v3 (91KB vs 48KB). Major additions: Auto Mode Pipeline tab logic, Company Mode batch processing rules, profile-scrubbing firms rule (D.E. Shaw etc.), discovery log mandate, ZoomInfo credits vs. discovery separation, low-LinkedIn-count failure signal rule.
- **`osi-3email-reengagement` added.** Was missing from v3.
- **`scripts/validate_email.py` added.** Called by `osi-outreach-sequence` at Step 9 before every queue write. Without it, all queue writes abort.
- **`knowledge/email-pattern-resolver.md` added.** Referenced by `osi-outreach-sequence` Step 5 for email address verification.
- **`config/do-not-auto-prospect.json` added.** Auto Mode reads this at startup. Missing file caused crashes in v3.
- **`config/prospects-tracker-new.xlsx` added.** Blank template with all 7 tabs and correct column headers pre-built: Tab1, Prospects, Company Status, Unenrolled, Companies Prospected, Do Not Auto-Prospect, Company Pipeline.
- **`scheduled-tasks/01-osi-email2-rewriter.md` added.** The third scheduled task was missing from v3.
- **SETUP.md fully rewritten** to cover all new files, 6-skill install, 3 scheduled tasks, Excel smoke test, and openpyxl check.
- **CLAUDE.md.template fully rewritten** with current Auto Mode rules, Pipeline tab logic, and accurate 6-skill inventory.

## Questions / contact

Built by Andy McLean (OSI Global). Questions: andy@osiglobal.com.
